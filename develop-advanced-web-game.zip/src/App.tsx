import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Game } from './game/engine';
import type { GameEvent, Hud } from './game/engine';
import { HudView } from './components/HudView';
import type { HitFx, HurtFx } from './components/HudView';
import { TouchControls } from './components/TouchControls';

type Screen = 'start' | 'loading' | 'playing' | 'paused' | 'dead' | 'won';

const QUALITIES: { key: string; label: string; hint: string }[] = [
  { key: 'auto', label: 'Авто', hint: 'подберём под устройство' },
  { key: 'low', label: 'Низкое', hint: 'для самых слабых' },
  { key: 'med', label: 'Среднее', hint: 'баланс' },
  { key: 'high', label: 'Высокое', hint: 'красиво' },
  { key: 'ultra', label: 'Ультра', hint: 'для мощных' },
];

function detectTouch() {
  return typeof window !== 'undefined' && (window.matchMedia?.('(pointer: coarse)').matches || 'ontouchstart' in window);
}

function autoQuality(touch: boolean) {
  const nav = navigator as Navigator & { deviceMemory?: number };
  const weak = (nav.hardwareConcurrency && nav.hardwareConcurrency <= 4) || (nav.deviceMemory && nav.deviceMemory <= 3);
  if (touch) return weak ? 'low' : 'med';
  return weak ? 'med' : 'high';
}

const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

function Palms() {
  return (
    <svg className="absolute bottom-0 left-0 w-full h-[55%] opacity-95" viewBox="0 0 1000 400" preserveAspectRatio="xMidYMax slice">
      <defs>
        <linearGradient id="sea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f7b267" />
          <stop offset="0.5" stopColor="#2aa6b8" />
          <stop offset="1" stopColor="#0a4a6e" />
        </linearGradient>
      </defs>
      <rect x="0" y="250" width="1000" height="150" fill="url(#sea)" opacity="0.9" />
      <path d="M0 330 Q250 290 500 320 T1000 300 V400 H0Z" fill="#0b2a2f" />
      <g fill="#07201f">
        <path d="M120 400 Q130 250 170 120 L180 122 Q150 260 150 400Z" />
        <path d="M170 120 Q90 90 40 130 Q100 105 168 125 Q120 70 60 60 Q130 80 172 118 Q170 50 190 10 Q190 70 176 118 Q230 60 300 70 Q230 85 180 124 Q250 110 310 150 Q240 125 176 128Z" />
        <path d="M840 400 Q835 280 800 160 L810 158 Q850 280 862 400Z" />
        <path d="M805 160 Q740 130 690 160 Q750 140 804 164 Q760 100 700 95 Q770 110 808 158 Q815 90 840 60 Q835 110 812 160 Q870 110 940 125 Q870 135 816 168 Q880 160 930 200 Q870 170 812 170Z" />
      </g>
    </svg>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const touch = useMemo(detectTouch, []);
  const [screen, setScreen] = useState<Screen>('start');
  const [quality, setQuality] = useState('auto');
  const [hud, setHud] = useState<Hud | null>(null);
  const [hurt, setHurt] = useState<HurtFx | null>(null);
  const [hit, setHit] = useState<HitFx | null>(null);
  const [toast, setToast] = useState<{ k: number; t: string } | null>(null);
  const [winTime, setWinTime] = useState(0);
  const [error, setError] = useState('');
  const [portrait, setPortrait] = useState(false);
  const kRef = useRef(0);

  const onEvent = useCallback((e: GameEvent) => {
    const k = ++kRef.current;
    switch (e.type) {
      case 'hurt':
        setHurt({ k, a: e.angle });
        break;
      case 'hit':
        setHit({ k, head: e.head, kill: e.kill });
        break;
      case 'pickup':
        setToast({ k, t: e.kind === 'med' ? '+ АПТЕЧКА' : '+ ПАТРОНЫ' });
        break;
      case 'dead':
        setTimeout(() => setScreen((s) => (s === 'playing' ? 'dead' : s)), 1200);
        break;
      case 'win':
        setWinTime(e.time);
        setTimeout(() => setScreen('won'), 900);
        break;
      case 'lockLost':
        setScreen((s) => (s === 'playing' ? 'paused' : s));
        break;
    }
  }, []);

  const begin = useCallback(async () => {
    setError('');
    setScreen('loading');
    if (touch) {
      try {
        document.documentElement.requestFullscreen?.().catch(() => {});
      } catch {
        /* ignore */
      }
      try {
        const o = window.screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> };
        o.lock?.('landscape').catch(() => {});
      } catch {
        /* ignore */
      }
    }
    await new Promise((r) => setTimeout(r, 120));
    try {
      const q = quality === 'auto' ? autoQuality(touch) : quality;
      if (!gameRef.current) {
        gameRef.current = new Game(canvasRef.current!, q, touch, setHud, onEvent);
      }
      gameRef.current.start();
      setScreen('playing');
    } catch (err) {
      console.error(err);
      setError('Не удалось запустить 3D (WebGL). Попробуйте другой браузер или обновите страницу.');
      setScreen('start');
    }
  }, [quality, touch, onEvent]);

  const pause = useCallback(() => {
    gameRef.current?.pause();
    setScreen('paused');
  }, []);

  const resume = useCallback(() => {
    gameRef.current?.resume();
    setScreen('playing');
  }, []);

  const restart = useCallback(() => {
    setHurt(null);
    gameRef.current?.start();
    setScreen('playing');
  }, []);

  useEffect(() => {
    const vis = () => {
      if (document.hidden) {
        gameRef.current?.pause();
        setScreen((s) => (s === 'playing' ? 'paused' : s));
      }
    };
    const rs = () => setPortrait(window.innerHeight > window.innerWidth);
    rs();
    const unlock = () => gameRef.current?.sfx.init();
    window.addEventListener('pointerdown', unlock);
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('resize', rs);
    return () => {
      document.removeEventListener('visibilitychange', vis);
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('resize', rs);
      gameRef.current?.dispose();
      gameRef.current = null;
    };
  }, []);

  const game = gameRef.current;
  const inGame = screen === 'playing' || screen === 'paused' || screen === 'dead' || screen === 'won';

  return (
    <div className="fixed inset-0 bg-[#0a1a24] overflow-hidden text-white no-select">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block" style={{ touchAction: 'none' }} />

      {inGame && game && (
        <>
          <HudView game={game} hud={hud} hurt={hurt} hit={hit} toast={toast} touch={touch} onPause={pause} />
          {touch && screen === 'playing' && <TouchControls game={game} />}
          {touch && portrait && screen === 'playing' && (
            <div className="absolute top-16 left-1/2 -translate-x-1/2 z-30 px-4 py-2 rounded-full bg-amber-500/90 text-black text-sm font-semibold pointer-events-none">Поверните телефон горизонтально ↻</div>
          )}
        </>
      )}

      {/* стартовый экран */}
      {(screen === 'start' || screen === 'loading') && (
        <div className="absolute inset-0 z-40 overflow-y-auto" style={{ background: 'linear-gradient(180deg,#0d2b4a 0%,#1d6f8f 38%,#f2a65a 68%,#ffd89b 100%)' }}>
          <div className="absolute top-[14%] right-[18%] w-28 h-28 rounded-full" style={{ background: 'radial-gradient(circle,#fff6c8 0%,#ffd36a 35%,rgba(255,180,60,0) 70%)', filter: 'blur(1px)' }} />
          <Palms />
          <div className="relative min-h-full flex flex-col items-center justify-center px-5 py-8 text-center">
            <div className="text-amber-200/90 tracking-[0.5em] text-xs sm:text-sm mb-1">3D · ОТКРЫТЫЙ ОСТРОВ · ОТ ПЕРВОГО ЛИЦА</div>
            <h1 className="title-glow text-6xl sm:text-8xl font-bold tracking-wider leading-none" style={{ color: '#fff4d6' }}>
              TROPIC <span className="text-amber-400">STRIKE</span>
            </h1>
            <p className="mt-3 max-w-md text-white/90 text-base sm:text-lg">
              Наёмники захватили тропический остров. Высадись на пляже, зачисти три базы и выживи. Укрытия, засады и меткая стрельба решают всё.
            </p>

            <div className="mt-6 w-full max-w-xl">
              <div className="text-xs tracking-[0.3em] text-white/70 mb-2">ГРАФИКА</div>
              <div className="grid grid-cols-5 gap-1.5">
                {QUALITIES.map((q) => (
                  <button
                    key={q.key}
                    onClick={() => setQuality(q.key)}
                    className={`rounded-lg py-2 px-1 border text-sm font-medium transition ${quality === q.key ? 'bg-amber-400 text-black border-amber-200 shadow-lg shadow-amber-500/30' : 'bg-black/35 border-white/25 text-white hover:bg-black/50'}`}
                  >
                    {q.label}
                  </button>
                ))}
              </div>
              <div className="text-[11px] text-white/70 mt-2">
                Умное динамическое разрешение само держит плавность даже на слабом телефоне — картинка остаётся с водой, пеной, ветром и дальностью прорисовки.
              </div>
            </div>

            {error && <div className="mt-4 px-4 py-2 rounded-lg bg-red-600/80 text-sm">{error}</div>}

            <button
              disabled={screen === 'loading'}
              onClick={begin}
              className="mt-6 px-14 py-4 rounded-xl bg-gradient-to-b from-amber-300 to-amber-500 text-black text-2xl font-bold tracking-[0.2em] shadow-[0_8px_30px_rgba(255,160,40,0.5)] active:scale-95 transition disabled:opacity-70"
            >
              {screen === 'loading' ? 'ГЕНЕРАЦИЯ ОСТРОВА…' : 'В БОЙ'}
            </button>

            <div className="mt-6 grid sm:grid-cols-2 gap-3 max-w-xl w-full text-left text-[13px]">
              <div className="rounded-xl bg-black/35 border border-white/15 p-3">
                <div className="text-amber-300 tracking-widest mb-1 text-xs">ТЕЛЕФОН</div>
                Левый палец — движение (дотяни до края — спринт). Правый — обзор. Красная кнопка — огонь (можно вести прицел, не отпуская). Есть прицеливание, прыжок и перезарядка.
              </div>
              <div className="rounded-xl bg-black/35 border border-white/15 p-3">
                <div className="text-amber-300 tracking-widest mb-1 text-xs">КОМПЬЮТЕР</div>
                WASD — ходьба, мышь — обзор, ЛКМ — огонь, ПКМ — прицел, Shift — бег, Пробел — прыжок, R — перезарядка, Esc — пауза.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* пауза */}
      {screen === 'paused' && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#0d2230]/95 border border-white/20 p-6 text-center">
            <div className="text-3xl font-bold tracking-widest mb-1">ПАУЗА</div>
            <div className="text-white/60 text-sm mb-5">
              Убито: {hud?.kills ?? 0} · осталось врагов: {hud?.enemies ?? 0}
            </div>
            <button onClick={resume} className="w-full py-3 rounded-lg bg-amber-400 text-black text-lg font-bold tracking-widest active:scale-95">
              ПРОДОЛЖИТЬ
            </button>
            <button onClick={restart} className="w-full mt-3 py-2.5 rounded-lg bg-white/10 border border-white/25 tracking-widest active:scale-95">
              НАЧАТЬ ЗАНОВО
            </button>
            <div className="text-[11px] text-white/45 mt-4">Разрешение рендера: {hud?.scale ?? 100}% · {hud?.fps ?? 0} FPS</div>
          </div>
        </div>
      )}

      {/* смерть */}
      {screen === 'dead' && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-red-950/70 backdrop-blur-[2px] px-4">
          <div className="text-center">
            <div className="text-6xl sm:text-7xl font-bold tracking-widest text-red-500 title-glow">ВЫ ПОГИБЛИ</div>
            <div className="text-white/80 mt-2">Убито наёмников: {hud?.kills ?? 0} из {hud?.total ?? 0}</div>
            <button onClick={restart} className="mt-6 px-10 py-3 rounded-xl bg-white text-black text-xl font-bold tracking-widest active:scale-95">
              ЕЩЁ РАЗ
            </button>
          </div>
        </div>
      )}

      {/* победа */}
      {screen === 'won' && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-emerald-950/70 backdrop-blur-[2px] px-4">
          <div className="text-center">
            <div className="text-5xl sm:text-7xl font-bold tracking-widest text-amber-300 title-glow">ОСТРОВ ЗАЧИЩЕН</div>
            <div className="text-white/85 mt-3 text-lg">
              Время: {fmt(winTime)} · Убито: {hud?.kills ?? 0}
            </div>
            <button onClick={restart} className="mt-6 px-10 py-3 rounded-xl bg-amber-400 text-black text-xl font-bold tracking-widest active:scale-95">
              ИГРАТЬ СНОВА
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
