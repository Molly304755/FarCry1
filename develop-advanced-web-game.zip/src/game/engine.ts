import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Sfx } from './audio';
import { Particles, Tracers, flashTexture, softTexture } from './fx';
import { HALF, WORLD, clamp, lerp } from './noise';
import { QUALITY, SUN_DIR, World } from './world';
import type { QualityCfg } from './world';

export interface Hud {
  hp: number;
  ammo: number;
  reserve: number;
  reloading: boolean;
  enemies: number;
  total: number;
  kills: number;
  aim: boolean;
  fps: number;
  scale: number;
  spread: number;
  alert: boolean;
}

export type GameEvent =
  | { type: 'hurt'; angle: number }
  | { type: 'hit'; head: boolean; kill: boolean }
  | { type: 'win'; time: number }
  | { type: 'dead' }
  | { type: 'pickup'; kind: string }
  | { type: 'lockLost' };

export interface Input {
  mx: number;
  mz: number;
  lookX: number;
  lookY: number;
  fire: boolean;
  aim: boolean;
  jump: boolean;
  reload: boolean;
  sprint: boolean;
}

type GState = 'menu' | 'playing' | 'paused' | 'dead' | 'won';

interface Enemy {
  g: THREE.Group;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  shadow: THREE.Mesh;
  x: number;
  z: number;
  y: number;
  yaw: number;
  hp: number;
  state: 0 | 1 | 2; // патруль, тревога, мёртв
  homeX: number;
  homeZ: number;
  tx: number;
  tz: number;
  hasT: boolean;
  wait: number;
  alertT: number;
  canSee: boolean;
  losT: number;
  fireCd: number;
  burst: number;
  burstT: number;
  aimDelay: number;
  strafe: number;
  strafeT: number;
  walk: number;
  moving: number;
  deathT: number;
}

interface Pickup {
  g: THREE.Group;
  kind: 'med' | 'ammo';
  x: number;
  z: number;
  y: number;
  t: number;
}

const MAG = 30;
const EYE = 1.65;

function part(geo: THREE.BufferGeometry, color: string, x: number, y: number, z: number, rx = 0, rz = 0) {
  const g = geo.index ? geo.toNonIndexed() : geo;
  g.deleteAttribute('uv');
  const c = new THREE.Color(color);
  const n = g.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    arr[i * 3] = c.r;
    arr[i * 3 + 1] = c.g;
    arr[i * 3 + 2] = c.b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  if (rx) g.rotateX(rx);
  if (rz) g.rotateZ(rz);
  g.translate(x, y, z);
  return g;
}

function raySphere(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, cx: number, cy: number, cz: number, r: number) {
  const lx = cx - ox;
  const ly = cy - oy;
  const lz = cz - oz;
  const tca = lx * dx + ly * dy + lz * dz;
  if (tca < 0) return -1;
  const d2 = lx * lx + ly * ly + lz * lz - tca * tca;
  if (d2 > r * r) return -1;
  return tca - Math.sqrt(r * r - d2);
}

const wrapAngle = (a: number) => {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
};

export class Game {
  canvas: HTMLCanvasElement;
  renderer: THREE.WebGLRenderer;
  camera: THREE.PerspectiveCamera;
  gunCam: THREE.PerspectiveCamera;
  gunScene = new THREE.Scene();
  world: World;
  sfx = new Sfx();
  cfg: QualityCfg;
  touch: boolean;
  onHud: (h: Hud) => void;
  onEvent: (e: GameEvent) => void;

  input: Input = { mx: 0, mz: 0, lookX: 0, lookY: 0, fire: false, aim: false, jump: false, reload: false, sprint: false };
  keys: Record<string, boolean> = {};
  state: GState = 'menu';

  // игрок
  p = { x: 0, z: 0, y: 0, vx: 0, vz: 0, vy: 0, yaw: 0, pitch: 0, hp: 100, onGround: true, ammo: MAG, reserve: 120, reloadT: 0, cd: 0, kick: 0, bobT: 0, stepD: 0, speed: 0 };
  adsT = 0;
  fov = 74;
  hurtT = 0;
  lastHurtSfx = 0;
  kills = 0;
  missionT = 0;
  emptyClicked = false;

  enemies: Enemy[] = [];
  pickups: Pickup[] = [];
  enemyGeo!: { body: THREE.BufferGeometry; leg: THREE.BufferGeometry; mats: THREE.Material[]; shadowGeo: THREE.BufferGeometry; shadowMat: THREE.Material };
  pickupRes!: { medBox: THREE.BufferGeometry; medCross: THREE.BufferGeometry; ammoBox: THREE.BufferGeometry; beam: THREE.BufferGeometry; mats: Record<string, THREE.Material> };

  fxScale = { value: 800 };
  sparks: Particles;
  smoke: Particles;
  tracers: Tracers;

  gun = new THREE.Group();
  gunBase = new THREE.Group();
  flash!: THREE.Sprite;
  flashLight!: THREE.PointLight;
  flashT = 0;
  swayX = 0;
  swayY = 0;

  // адаптивное разрешение
  scale = 0.9;
  frames = 0;
  acc = 0;
  fps = 60;
  lastDown = 0;

  raf = 0;
  last = 0;
  time = 0;
  hudT = 0;
  mapCanvas: HTMLCanvasElement | null = null;
  mapImg: HTMLCanvasElement;
  mapT = 0;
  orbit = 0;
  cleanup: (() => void)[] = [];
  tmpV = new THREE.Vector3();
  tmpV2 = new THREE.Vector3();
  tmpC = new THREE.Color();

  constructor(canvas: HTMLCanvasElement, qualityKey: string, touch: boolean, onHud: (h: Hud) => void, onEvent: (e: GameEvent) => void) {
    this.canvas = canvas;
    this.touch = touch;
    this.onHud = onHud;
    this.onEvent = onEvent;
    this.cfg = QUALITY[qualityKey] || QUALITY.med;
    this.scale = touch ? 0.9 : 1;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: this.cfg.aa, powerPreference: 'high-performance', stencil: false });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.autoClear = false;
    this.camera = new THREE.PerspectiveCamera(this.fov, 1, 0.1, 1600);
    this.camera.rotation.order = 'YXZ';
    this.gunCam = new THREE.PerspectiveCamera(52, 1, 0.02, 10);

    this.world = new World(this.cfg);
    this.world.scene.add(this.camera);

    this.sparks = new Particles(220, true, this.fxScale);
    this.smoke = new Particles(260, false, this.fxScale);
    this.world.scene.add(this.sparks.points, this.smoke.points);
    this.tracers = new Tracers(this.world.scene, 28);

    this.buildEnemyAssets();
    this.buildPickupAssets();
    this.buildGun();
    this.mapImg = this.bakeMap();

    this.resize();
    this.bindInput();
    this.resetGame();
    this.state = 'menu';
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  // ---------------------------------------------------------------- ресурсы
  private buildEnemyAssets() {
    const B = (x: number, y: number, z: number) => new THREE.BoxGeometry(x, y, z);
    const body = mergeGeometries([
      part(B(0.5, 0.62, 0.28), '#6b7a46', 0, 1.12, 0),
      part(B(0.54, 0.4, 0.32), '#3b4430', 0, 1.18, 0),
      part(B(0.55, 0.09, 0.3), '#222', 0, 0.82, 0),
      part(B(0.25, 0.27, 0.25), '#c99a76', 0, 1.6, 0),
      part(B(0.3, 0.11, 0.3), '#47502e', 0, 1.74, 0),
      part(B(0.12, 0.12, 0.05), '#222', 0, 1.62, 0.13),
      part(B(0.13, 0.5, 0.13), '#6b7a46', 0.33, 1.15, 0.2, -1.2),
      part(B(0.13, 0.5, 0.13), '#6b7a46', -0.27, 1.17, 0.3, -1.35),
      part(B(0.07, 0.1, 0.85), '#1b1b1b', 0.15, 1.18, 0.5),
      part(B(0.06, 0.2, 0.09), '#2b2b2b', 0.15, 1.04, 0.45),
    ])!;
    const leg = mergeGeometries([part(B(0.2, 0.78, 0.22), '#55553c', 0, -0.39, 0), part(B(0.22, 0.14, 0.3), '#1d1d1d', 0, -0.73, 0.04)])!;
    const mats = ['#ffffff', '#ead2bd', '#c2cfdd'].map((c) => new THREE.MeshLambertMaterial({ vertexColors: true, color: c }));
    const sh = new THREE.CircleGeometry(0.8, 14);
    sh.rotateX(-Math.PI / 2);
    const shadowMat = new THREE.MeshBasicMaterial({ map: softTexture('rgba(0,0,0,0.65)', 'rgba(0,0,0,0)'), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, fog: false });
    this.enemyGeo = { body, leg, mats, shadowGeo: sh, shadowMat };
  }

  private buildPickupAssets() {
    const medBox = new THREE.BoxGeometry(0.5, 0.35, 0.36);
    const medCross = mergeGeometries([new THREE.BoxGeometry(0.28, 0.02, 0.08), new THREE.BoxGeometry(0.08, 0.02, 0.28)])!;
    const ammoBox = new THREE.BoxGeometry(0.5, 0.3, 0.3);
    const beam = new THREE.CylinderGeometry(0.18, 0.18, 7, 8, 1, true);
    beam.translate(0, 3.5, 0);
    const mats: Record<string, THREE.Material> = {
      med: new THREE.MeshLambertMaterial({ color: '#f2f2f2' }),
      cross: new THREE.MeshBasicMaterial({ color: '#d4261d' }),
      ammo: new THREE.MeshLambertMaterial({ color: '#5f6e3a' }),
      beamMed: new THREE.MeshBasicMaterial({ color: '#ff5a4d', transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }),
      beamAmmo: new THREE.MeshBasicMaterial({ color: '#ffd24d', transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }),
    };
    this.pickupRes = { medBox, medCross, ammoBox, beam, mats };
  }

  private buildGun() {
    const M = (c: string) => new THREE.MeshLambertMaterial({ color: c });
    const add = (geo: THREE.BufferGeometry, color: string, x: number, y: number, z: number, rx = 0) => {
      const m = new THREE.Mesh(geo, M(color));
      m.position.set(x, y, z);
      m.rotation.x = rx;
      this.gun.add(m);
      return m;
    };
    const B = (x: number, y: number, z: number) => new THREE.BoxGeometry(x, y, z);
    add(B(0.06, 0.09, 0.42), '#34373d', 0, 0, 0);
    add(B(0.062, 0.05, 0.3), '#23252a', 0, 0.065, -0.02);
    add(B(0.02, 0.025, 0.1), '#15161a', 0, 0.1, -0.15);
    add(B(0.02, 0.03, 0.02), '#15161a', 0, 0.1, 0.12);
    add(B(0.055, 0.07, 0.24), '#4a4d54', 0, -0.005, -0.32);
    const barrel = add(new THREE.CylinderGeometry(0.012, 0.014, 0.3, 8), '#15161a', 0, 0.012, -0.6, Math.PI / 2);
    barrel.scale.set(1, 1, 1);
    add(new THREE.CylinderGeometry(0.02, 0.02, 0.07, 8), '#101114', 0, 0.012, -0.76, Math.PI / 2);
    add(B(0.045, 0.085, 0.24), '#5a4631', 0, -0.015, 0.31);
    add(B(0.04, 0.11, 0.055), '#2b2c30', 0, -0.095, 0.07, 0.25);
    add(B(0.038, 0.14, 0.075), '#1f2024', 0, -0.1, -0.1, -0.15);
    // руки (перчатки)
    add(B(0.07, 0.07, 0.14), '#2b2a28', 0, -0.045, -0.32);
    add(B(0.075, 0.075, 0.45), '#3a4a30', -0.03, -0.09, -0.58 + 0.12, 0).rotation.set(0.35, 0.18, 0);
    add(B(0.06, 0.09, 0.08), '#2b2a28', 0.0, -0.075, 0.07);
    add(B(0.08, 0.08, 0.4), '#3a4a30', 0.07, -0.18, 0.25).rotation.set(-0.35, -0.22, 0);

    this.gunBase.add(this.gun);
    this.gunScene.add(this.gunBase);
    this.gunScene.add(new THREE.HemisphereLight('#cfe9ff', '#7a6a4a', 2.2));
    const dl = new THREE.DirectionalLight('#fff0d0', 3.4);
    dl.position.copy(SUN_DIR);
    this.gunScene.add(dl);
    this.flashLight = new THREE.PointLight('#ffb050', 0, 3);
    this.flashLight.position.set(0, 0.05, -0.9);
    this.gun.add(this.flashLight);
    const fm = new THREE.SpriteMaterial({ map: flashTexture(), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, toneMapped: false });
    this.flash = new THREE.Sprite(fm);
    this.flash.position.set(0, 0.012, -0.84);
    this.flash.visible = false;
    this.gun.add(this.flash);
    this.gunScene.add(this.gunCam);
  }

  private bakeMap() {
    const cv = document.createElement('canvas');
    cv.width = cv.height = WORLD;
    const c = cv.getContext('2d')!;
    const img = c.createImageData(WORLD, WORLD);
    const G = WORLD + 1;
    const H = this.world.heights;
    for (let z = 0; z < WORLD; z++) {
      for (let x = 0; x < WORLD; x++) {
        const h = H[z * G + x];
        let r: number, g: number, b: number;
        if (h < -4) [r, g, b] = [14, 80, 140];
        else if (h < -1.5) [r, g, b] = [24, 135, 175];
        else if (h < 0) [r, g, b] = [80, 205, 195];
        else if (h < 1) [r, g, b] = [236, 216, 152];
        else if (h < 4) [r, g, b] = [130, 180, 74];
        else if (h < 9) [r, g, b] = [74, 135, 58];
        else if (h < 14) [r, g, b] = [115, 112, 100];
        else [r, g, b] = [172, 170, 165];
        const k = (z * WORLD + x) * 4;
        img.data[k] = r;
        img.data[k + 1] = g;
        img.data[k + 2] = b;
        img.data[k + 3] = 255;
      }
    }
    c.putImageData(img, 0, 0);
    return cv;
  }

  // ---------------------------------------------------------------- ввод
  private bindInput() {
    const kd = (e: KeyboardEvent) => {
      this.keys[e.code] = true;
      if (e.code === 'KeyR') this.input.reload = true;
      if (e.code === 'Space') {
        this.input.jump = true;
        e.preventDefault();
      }
    };
    const ku = (e: KeyboardEvent) => {
      this.keys[e.code] = false;
    };
    const mm = (e: MouseEvent) => {
      if (document.pointerLockElement !== this.canvas || this.state !== 'playing') return;
      this.input.lookX += e.movementX * 0.0022;
      this.input.lookY += e.movementY * 0.0022;
    };
    const md = (e: MouseEvent) => {
      if (this.touch || this.state !== 'playing') return;
      if (e.button === 0) this.input.fire = true;
      if (e.button === 2) this.input.aim = true;
    };
    const mu = (e: MouseEvent) => {
      if (e.button === 0) this.input.fire = false;
      if (e.button === 2) this.input.aim = false;
    };
    const cm = (e: Event) => e.preventDefault();
    const plc = () => {
      if (!this.touch && document.pointerLockElement !== this.canvas && this.state === 'playing') {
        this.state = 'paused';
        this.onEvent({ type: 'lockLost' });
      }
    };
    const rs = () => this.resize();
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);
    document.addEventListener('mousemove', mm);
    window.addEventListener('mousedown', md);
    window.addEventListener('mouseup', mu);
    window.addEventListener('contextmenu', cm);
    document.addEventListener('pointerlockchange', plc);
    window.addEventListener('resize', rs);
    window.addEventListener('orientationchange', rs);
    this.cleanup.push(() => {
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
      document.removeEventListener('mousemove', mm);
      window.removeEventListener('mousedown', md);
      window.removeEventListener('mouseup', mu);
      window.removeEventListener('contextmenu', cm);
      document.removeEventListener('pointerlockchange', plc);
      window.removeEventListener('resize', rs);
      window.removeEventListener('orientationchange', rs);
    });
  }

  resize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    const pr = Math.max(0.4, Math.min(window.devicePixelRatio || 1, this.cfg.cap) * this.scale);
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.gunCam.aspect = w / h;
    this.gunCam.fov = w / h < 1 ? 70 : 52;
    this.gunCam.updateProjectionMatrix();
  }

  // ---------------------------------------------------------------- управление состоянием
  start() {
    this.sfx.init();
    this.resetGame();
    this.state = 'playing';
    this.tryLock();
  }

  tryLock() {
    if (!this.touch) {
      try {
        const r = this.canvas.requestPointerLock() as unknown as Promise<void> | undefined;
        if (r && typeof r.catch === 'function') r.catch(() => {});
      } catch {
        /* ignore */
      }
    }
  }

  pause() {
    if (this.state === 'playing') {
      this.state = 'paused';
      this.input.fire = false;
      this.input.aim = false;
      if (document.pointerLockElement) document.exitPointerLock();
    }
  }

  resume() {
    if (this.state === 'paused') {
      this.sfx.init();
      this.state = 'playing';
      this.tryLock();
    }
  }

  resetGame() {
    const w = this.world;
    for (const e of this.enemies) {
      w.scene.remove(e.g);
      w.scene.remove(e.shadow);
    }
    for (const pk of this.pickups) w.scene.remove(pk.g);
    this.enemies = [];
    this.pickups = [];
    this.kills = 0;
    this.missionT = 0;
    const p = this.p;
    p.x = w.spawn.x;
    p.z = w.spawn.z;
    p.y = w.heightAt(p.x, p.z);
    p.vx = p.vz = p.vy = 0;
    p.yaw = 0;
    p.pitch = -0.05;
    p.hp = 100;
    p.ammo = MAG;
    p.reserve = 150;
    p.reloadT = 0;
    p.cd = 0;
    p.kick = 0;
    this.hurtT = 0;
    this.adsT = 0;
    this.input.lookX = this.input.lookY = 0;
    this.input.fire = this.input.aim = this.input.jump = this.input.reload = false;
    this.spawnEnemies();
    for (const o of w.outposts) {
      this.addPickup('med', o.x + 2, o.z - 2);
      this.addPickup('ammo', o.x - 3, o.z + 3);
      this.addPickup('ammo', o.x + 5, o.z + 1);
    }
    this.addPickup('ammo', p.x + 3, p.z - 6);
  }

  private spawnEnemies() {
    const w = this.world;
    let id = 0;
    const make = (x: number, z: number) => {
      const e = this.makeEnemy(x, z, id++);
      this.enemies.push(e);
    };
    for (const o of w.outposts) {
      let n = 0;
      for (let t = 0; t < 200 && n < 5; t++) {
        const a = Math.random() * Math.PI * 2;
        const r = 3 + Math.random() * 10;
        const x = o.x + Math.cos(a) * r;
        const z = o.z + Math.sin(a) * r;
        if (!w.free(x, z, 0.9)) continue;
        make(x, z);
        n++;
      }
    }
    let n = 0;
    for (let t = 0; t < 600 && n < 4; t++) {
      const x = (Math.random() * 2 - 1) * 130;
      const z = (Math.random() * 2 - 1) * 130;
      const h = w.heightAt(x, z);
      if (h < 1.5 || !w.free(x, z, 1) || Math.hypot(x - w.spawn.x, z - w.spawn.z) < 70) continue;
      if (w.outposts.some((o) => Math.hypot(o.x - x, o.z - z) < 35)) continue;
      make(x, z);
      n++;
    }
  }

  private makeEnemy(x: number, z: number, id: number): Enemy {
    const R = this.enemyGeo;
    const mat = R.mats[id % R.mats.length];
    const g = new THREE.Group();
    g.rotation.order = 'YXZ';
    const body = new THREE.Mesh(R.body, mat);
    const legL = new THREE.Mesh(R.leg, mat);
    const legR = new THREE.Mesh(R.leg, mat);
    legL.position.set(-0.13, 0.8, 0);
    legR.position.set(0.13, 0.8, 0);
    g.add(body, legL, legR);
    const shadow = new THREE.Mesh(R.shadowGeo, R.shadowMat);
    shadow.renderOrder = 1;
    this.world.scene.add(g, shadow);
    const y = this.world.heightAt(x, z);
    g.position.set(x, y, z);
    const yaw = Math.random() * Math.PI * 2;
    return {
      g, legL, legR, shadow, x, z, y, yaw, hp: 100, state: 0, homeX: x, homeZ: z, tx: x, tz: z, hasT: false, wait: Math.random() * 3,
      alertT: 0, canSee: false, losT: Math.random() * 0.3, fireCd: 1 + Math.random(), burst: 0, burstT: 0, aimDelay: 0.7,
      strafe: Math.random() < 0.5 ? 1 : -1, strafeT: 1, walk: 0, moving: 0, deathT: 0,
    };
  }

  private addPickup(kind: 'med' | 'ammo', x: number, z: number) {
    const R = this.pickupRes;
    const g = new THREE.Group();
    if (kind === 'med') {
      g.add(new THREE.Mesh(R.medBox, R.mats.med));
      const c = new THREE.Mesh(R.medCross, R.mats.cross);
      c.position.y = 0.19;
      g.add(c);
    } else {
      g.add(new THREE.Mesh(R.ammoBox, R.mats.ammo));
    }
    g.add(new THREE.Mesh(R.beam, kind === 'med' ? R.mats.beamMed : R.mats.beamAmmo));
    const y = this.world.groundAt(x, z, 99);
    g.position.set(x, y + 0.5, z);
    this.world.scene.add(g);
    this.pickups.push({ g, kind, x, z, y, t: Math.random() * 6 });
  }

  // ---------------------------------------------------------------- главный цикл
  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    let raw = (now - this.last) / 1000;
    this.last = now;
    if (raw <= 0) return;
    if (raw < 0.25) this.measure(raw);
    const dt = Math.min(raw, 0.05);
    this.time += dt;

    if (this.state === 'playing') this.update(dt);
    else if (this.state === 'menu') this.updateMenu(dt);
    else if (this.state === 'dead') this.updateDead(dt);
    else if (this.state === 'won') this.updateWon(dt);

    this.render();
  };

  private measure(dt: number) {
    this.frames++;
    this.acc += dt;
    if (this.acc < 1.3) return;
    const avg = this.acc / this.frames;
    this.fps = 1 / avg;
    this.acc = 0;
    this.frames = 0;
    const t = this.time;
    if (avg > 0.024 && this.scale > this.cfg.minScale + 0.001) {
      this.scale = Math.max(this.cfg.minScale, this.scale * (avg > 0.04 ? 0.78 : 0.88));
      this.lastDown = t;
      this.resize();
    } else if (avg < 0.0182 && this.scale < 1 && t - this.lastDown > 7) {
      this.scale = Math.min(1, this.scale * 1.08);
      this.resize();
    }
  }

  private render() {
    const r = this.renderer;
    r.clear();
    this.fxScale.value = (r.domElement.height * 0.5) / Math.tan((this.camera.fov * Math.PI) / 360);
    r.render(this.world.scene, this.camera);
    if (this.state === 'playing' || this.state === 'paused') {
      r.clearDepth();
      r.render(this.gunScene, this.gunCam);
    }
  }

  private updateMenu(dt: number) {
    this.orbit += dt * 0.05;
    const R = 175;
    this.camera.position.set(Math.cos(this.orbit) * R, 38 + Math.sin(this.orbit * 2) * 5, Math.sin(this.orbit) * R);
    this.camera.lookAt(0, 6, 0);
    this.camera.fov = 62;
    this.camera.updateProjectionMatrix();
    this.world.update(this.time, this.camera.position);
  }

  private updateDead(dt: number) {
    const p = this.p;
    p.pitch = lerp(p.pitch, -0.2, dt * 2);
    this.hurtT = Math.max(this.hurtT, 0.6);
    const ey = lerp(this.camera.position.y, this.world.heightAt(p.x, p.z) + 0.35, dt * 4);
    this.camera.position.y = ey;
    this.camera.rotation.z = lerp(this.camera.rotation.z, 0.7, dt * 2);
    for (const e of this.enemies) this.updateEnemy(e, dt);
    this.updateFx(dt);
    this.world.update(this.time, this.camera.position);
  }

  private updateWon(dt: number) {
    for (const e of this.enemies) this.updateEnemy(e, dt);
    this.updateFx(dt);
    this.world.update(this.time, this.camera.position);
  }

  // ---------------------------------------------------------------- обновление игры
  private update(dt: number) {
    const p = this.p;
    const inp = this.input;
    const w = this.world;
    this.missionT += dt;

    // обзор
    const ads = inp.aim && p.reloadT <= 0 ? 1 : 0;
    this.adsT = clamp(this.adsT + (ads ? 1 : -1) * dt * 8, 0, 1);
    const lookMul = lerp(1, 0.5, this.adsT);
    p.yaw -= inp.lookX * lookMul;
    p.pitch = clamp(p.pitch - inp.lookY * lookMul, -1.45, 1.45);
    inp.lookX = inp.lookY = 0;

    // движение
    const k = this.keys;
    let mx = inp.mx + ((k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0));
    let mz = inp.mz + ((k.KeyW || k.ArrowUp ? 1 : 0) - (k.KeyS || k.ArrowDown ? 1 : 0));
    const mag = Math.hypot(mx, mz);
    if (mag > 1) {
      mx /= mag;
      mz /= mag;
    }
    const wantSprint = (inp.sprint || k.ShiftLeft || k.ShiftRight) && mz > 0.3 && this.adsT < 0.3;
    const sin = Math.sin(p.yaw);
    const cos = Math.cos(p.yaw);
    const fx = -sin;
    const fz = -cos;
    const rx = cos;
    const rz = -sin;
    const wet = w.heightAt(p.x, p.z) < 0.25 && p.onGround;
    let speed = wantSprint ? 8.4 : 5.2;
    speed *= lerp(1, 0.55, this.adsT);
    if (wet) speed *= 0.72;
    const tvx = (fx * mz + rx * mx) * speed;
    const tvz = (fz * mz + rz * mx) * speed;
    const acc = p.onGround ? 14 : 3;
    const a = Math.min(1, acc * dt);
    p.vx += (tvx - p.vx) * a;
    p.vz += (tvz - p.vz) * a;

    const nx = p.x + p.vx * dt;
    const nz = p.z + p.vz * dt;
    if (w.heightAt(nx, nz) > -1.3) {
      p.x = nx;
      p.z = nz;
    } else if (w.heightAt(nx, p.z) > -1.3) p.x = nx;
    else if (w.heightAt(p.x, nz) > -1.3) p.z = nz;
    p.x = clamp(p.x, -HALF + 3, HALF - 3);
    p.z = clamp(p.z, -HALF + 3, HALF - 3);
    const pos = { x: p.x, z: p.z };
    w.collide(pos, 0.45, p.y);
    p.x = pos.x;
    p.z = pos.z;
    p.speed = Math.hypot(p.vx, p.vz);

    if (inp.jump) {
      if (p.onGround) {
        p.vy = 6.4;
        p.onGround = false;
        this.sfx.jump();
      }
      inp.jump = false;
    }
    const g = w.groundAt(p.x, p.z, p.y);
    if (p.onGround && p.y - g < 0.55 && p.vy <= 0) {
      p.y = g;
    } else {
      p.vy -= 17 * dt;
      p.y += p.vy * dt;
      p.onGround = false;
      if (p.y <= g) {
        p.y = g;
        if (p.vy < -9) this.damagePlayer((-p.vy - 9) * 6, p.x, p.z, false);
        p.vy = 0;
        p.onGround = true;
      }
    }

    // шаги и покачивание
    const mv = p.onGround ? clamp(p.speed / 5.2, 0, 1.6) : 0;
    p.bobT += p.speed * dt * 1.35;
    p.stepD += p.speed * dt * (p.onGround ? 1 : 0);
    if (p.stepD > (wantSprint ? 3.0 : 2.1)) {
      p.stepD = 0;
      this.sfx.step();
    }

    // стрельба / перезарядка
    p.cd -= dt;
    p.kick = Math.max(0, p.kick - dt * 7);
    if (inp.reload) {
      inp.reload = false;
      this.startReload();
    }
    if (p.reloadT > 0) {
      p.reloadT -= dt;
      if (p.reloadT <= 0) {
        const take = Math.min(MAG - p.ammo, p.reserve);
        p.ammo += take;
        p.reserve -= take;
      }
    } else if (inp.fire && p.cd <= 0 && !(wantSprint && p.speed > 7)) {
      if (p.ammo > 0) {
        this.shoot(mv, wantSprint);
        this.emptyClicked = false;
      } else if (p.reserve > 0) this.startReload();
      else if (!this.emptyClicked) {
        this.emptyClicked = true;
        this.sfx.empty();
      }
    }
    if (!inp.fire) this.emptyClicked = false;

    // враги, предметы, эффекты
    for (const e of this.enemies) this.updateEnemy(e, dt);
    this.updatePickups(dt);
    this.updateFx(dt);

    // камера
    this.hurtT = Math.max(0, this.hurtT - dt * 1.4);
    const bobY = Math.sin(p.bobT * 2) * 0.045 * mv * (1 - this.adsT * 0.7);
    const bobX = Math.cos(p.bobT) * 0.02 * mv * (1 - this.adsT * 0.7);
    const shake = this.hurtT * 0.012;
    const cam = this.camera;
    cam.position.set(p.x + rx * bobX, p.y + EYE + bobY, p.z + rz * bobX);
    cam.rotation.set(p.pitch + (Math.random() - 0.5) * shake, p.yaw + (Math.random() - 0.5) * shake, 0);
    const targetFov = (this.touch ? 70 : 76) + (wantSprint ? 5 : 0) - this.adsT * 32;
    this.fov += (targetFov - this.fov) * Math.min(1, dt * 10);
    if (Math.abs(cam.fov - this.fov) > 0.02) {
      cam.fov = this.fov;
      cam.updateProjectionMatrix();
    }
    w.update(this.time, cam.position);
    this.animateGun(dt, mv, wantSprint);

    // подсказки интерфейса
    this.hudT -= dt;
    if (this.hudT <= 0) {
      this.hudT = 0.1;
      this.emitHud(mv);
      this.drawMap();
    }
    this.checkProgress();
  }

  private emitHud(mv: number) {
    const p = this.p;
    const alive = this.enemies.filter((e) => e.state !== 2);
    this.onHud({
      hp: Math.max(0, Math.round(p.hp)),
      ammo: p.ammo,
      reserve: p.reserve,
      reloading: p.reloadT > 0,
      enemies: alive.length,
      total: this.enemies.length,
      kills: this.kills,
      aim: this.adsT > 0.5,
      fps: Math.round(this.fps),
      scale: Math.round(this.scale * 100),
      spread: clamp(mv * 0.6 + p.kick * 0.5 + (p.onGround ? 0 : 0.5), 0, 1) * (1 - this.adsT * 0.7),
      alert: alive.some((e) => e.state === 1),
    });
  }

  private checkProgress() {
    if (this.state !== 'playing') return;
    if (this.p.hp <= 0) {
      this.state = 'dead';
      this.input.fire = false;
      this.input.aim = false;
      this.sfx.lose();
      if (document.pointerLockElement) document.exitPointerLock();
      this.emitHud(0);
      this.onEvent({ type: 'dead' });
    } else if (this.enemies.length && this.enemies.every((e) => e.state === 2)) {
      this.state = 'won';
      this.input.fire = false;
      this.sfx.win();
      if (document.pointerLockElement) document.exitPointerLock();
      this.emitHud(0);
      this.onEvent({ type: 'win', time: this.missionT });
    }
  }

  // ---------------------------------------------------------------- оружие
  private startReload() {
    const p = this.p;
    if (p.reloadT > 0 || p.ammo >= MAG || p.reserve <= 0) return;
    p.reloadT = 1.9;
    this.sfx.reload();
  }

  private shoot(mv: number, sprint: boolean) {
    const p = this.p;
    const w = this.world;
    const cam = this.camera;
    p.ammo--;
    p.cd = 0.095;
    p.kick = 1;
    this.flashT = 0.055;
    this.sfx.shot(0.9);

    const spread = (0.0035 + mv * 0.012 + (p.onGround ? 0 : 0.03) + (sprint ? 0.02 : 0)) * (1 - this.adsT * 0.75);
    cam.updateMatrixWorld();
    const dir = this.tmpV.set(0, 0, -1).applyQuaternion(cam.quaternion);
    const right = this.tmpV2.set(1, 0, 0).applyQuaternion(cam.quaternion);
    const up = new THREE.Vector3(0, 1, 0).applyQuaternion(cam.quaternion);
    const sx = (Math.random() - 0.5) * 2 * spread;
    const sy = (Math.random() - 0.5) * 2 * spread;
    dir.addScaledVector(right, sx).addScaledVector(up, sy).normalize();
    const d = dir.clone();
    const ox = cam.position.x;
    const oy = cam.position.y;
    const oz = cam.position.z;

    // отдача
    const rk = (this.touch ? 0.0042 : 0.006) * (1 - this.adsT * 0.4);
    p.pitch = Math.min(1.45, p.pitch + rk * (0.7 + Math.random() * 0.6));
    p.yaw += (Math.random() - 0.5) * rk * 0.8;

    // враги услышали
    for (const e of this.enemies) {
      if (e.state === 0 && Math.hypot(e.x - p.x, e.z - p.z) < 55) this.alertEnemy(e);
    }

    // попадание по врагу
    let bestT = Infinity;
    let bestE: Enemy | null = null;
    let bestPart = 1;
    const assist = this.touch ? 1.3 : 1;
    for (const e of this.enemies) {
      if (e.state === 2) continue;
      const dx = e.x - ox;
      const dz = e.z - oz;
      if (dx * dx + dz * dz > 230 * 230) continue;
      const tests: [number, number, number][] = [
        [1.66, 0.25 * assist, 0],
        [1.12, 0.4 * assist, 1],
        [0.5, 0.34 * assist, 2],
      ];
      for (const [cy, r, part] of tests) {
        const t = raySphere(ox, oy, oz, d.x, d.y, d.z, e.x, e.y + cy, e.z, r);
        if (t >= 0 && t < bestT) {
          bestT = t;
          bestE = e;
          bestPart = part;
        }
      }
    }
    const wt = w.rayBlocked(ox, oy, oz, d.x, d.y, d.z, 220);
    const tw = d.y < -0.0001 ? (-0.02 - oy) / d.y : Infinity;
    const muzzle = cam.localToWorld(this.tmpV2.set(this.adsT > 0.5 ? 0.0 : 0.17, this.adsT > 0.5 ? -0.07 : -0.13, -0.9));
    const end = new THREE.Vector3();

    if (bestE && bestT < wt && bestT < tw) {
      end.set(ox + d.x * bestT, oy + d.y * bestT, oz + d.z * bestT);
      const head = bestPart === 0;
      const dmg = head ? 78 : bestPart === 1 ? 30 : 20;
      this.blood(end, d);
      this.hitEnemy(bestE, dmg, head);
    } else if (tw < wt && tw < 200) {
      end.set(ox + d.x * tw, -0.02, oz + d.z * tw);
      this.splash(end);
    } else if (wt < 200) {
      end.set(ox + d.x * wt, oy + d.y * wt, oz + d.z * wt);
      this.impact(end, d);
    } else {
      end.set(ox + d.x * 160, oy + d.y * 160, oz + d.z * 160);
    }
    if (end.distanceTo(muzzle) > 3) this.tracers.fire(muzzle.clone(), end);
    // дымок на дуле
    this.tmpC.set('#d8d8d8');
    this.smoke.emit(muzzle.x, muzzle.y, muzzle.z, d.x * 0.6, 0.35, d.z * 0.6, 0.7, 0.18, this.tmpC, 0.22, -0.2, 3);
  }

  private hitEnemy(e: Enemy, dmg: number, head: boolean) {
    e.hp -= dmg;
    if (e.state === 0) this.alertEnemy(e);
    e.alertT = 12;
    e.aimDelay = Math.max(e.aimDelay, 0.25);
    let kill = false;
    if (e.hp <= 0) {
      kill = true;
      this.killEnemy(e);
    }
    this.sfx[head ? 'headshot' : 'hit']();
    this.onEvent({ type: 'hit', head, kill });
  }

  private alertEnemy(e: Enemy) {
    if (e.state === 2) return;
    e.state = 1;
    e.alertT = 12;
    e.hasT = false;
    e.aimDelay = 0.55 + Math.random() * 0.5;
    // соседи тоже реагируют
    for (const o of this.enemies) {
      if (o.state === 0 && Math.hypot(o.x - e.x, o.z - e.z) < 18) {
        o.state = 1;
        o.alertT = 9;
        o.aimDelay = 0.8 + Math.random() * 0.8;
      }
    }
  }

  private killEnemy(e: Enemy) {
    e.state = 2;
    e.deathT = 0;
    e.shadow.visible = false;
    this.kills++;
    this.sfx.kill();
    const r = Math.random();
    if (r < 0.36) this.addPickup('ammo', e.x + 0.5, e.z);
    else if (r < 0.5) this.addPickup('med', e.x + 0.5, e.z);
  }

  // ---------------------------------------------------------------- ИИ врагов
  private updateEnemy(e: Enemy, dt: number) {
    const w = this.world;
    const p = this.p;
    if (e.state === 2) {
      if (e.deathT < 3) {
        e.deathT += dt;
        e.g.rotation.x = -Math.min(1, e.deathT * 3.2) * 1.5;
        e.g.position.y = e.y + Math.min(1, e.deathT * 3.2) * 0.1;
        if (e.deathT > 2.5) e.g.position.y = e.y + 0.12;
      }
      return;
    }
    const playerAlive = this.state === 'playing';
    const dx = p.x - e.x;
    const dz = p.z - e.z;
    const dist = Math.hypot(dx, dz) || 0.001;

    // восприятие
    e.losT -= dt;
    if (e.losT <= 0 && playerAlive) {
      e.losT = 0.2 + Math.random() * 0.12;
      let see = false;
      const sprinting = p.speed > 6.5;
      const range = e.state === 1 ? 95 : (sprinting ? 62 : 46) * (this.adsT > 0.5 ? 0.85 : 1);
      if (dist < range) {
        const fx = Math.sin(e.yaw);
        const fz = Math.cos(e.yaw);
        const cosA = (dx * fx + dz * fz) / dist;
        if (e.state === 1 || cosA > 0.3 || dist < 9) {
          const ey = e.y + 1.6;
          const ty = p.y + 1.4;
          const dy = ty - ey;
          const len = Math.hypot(dx, dy, dz);
          see = w.rayBlocked(e.x, ey, e.z, dx / len, dy / len, dz / len, len - 0.6) === Infinity;
        }
      }
      e.canSee = see;
      if (see) {
        e.alertT = 10;
        if (e.state === 0) this.alertEnemy(e);
      }
    }
    if (!playerAlive) e.canSee = false;

    if (e.state === 1) {
      if (!e.canSee) {
        e.alertT -= dt;
        if (e.alertT <= 0 || !playerAlive) {
          e.state = 0;
          e.homeX = e.x;
          e.homeZ = e.z;
          e.hasT = false;
        }
      }
      // поворот к игроку
      const want = Math.atan2(dx, dz);
      const diff = wrapAngle(want - e.yaw);
      e.yaw += clamp(diff, -7 * dt, 7 * dt);

      let mvx = 0;
      let mvz = 0;
      let spd = 0;
      if (e.canSee) {
        e.aimDelay -= dt;
        const nxn = dx / dist;
        const nzn = dz / dist;
        if (dist > 34) {
          mvx = nxn;
          mvz = nzn;
          spd = 3.8;
        } else if (dist < 9) {
          mvx = -nxn;
          mvz = -nzn;
          spd = 2.6;
        } else {
          e.strafeT -= dt;
          if (e.strafeT <= 0) {
            e.strafe = Math.random() < 0.5 ? 1 : -1;
            e.strafeT = 1.2 + Math.random() * 2;
          }
          mvx = -nzn * e.strafe;
          mvz = nxn * e.strafe;
          spd = 2.2;
        }
        if (e.aimDelay <= 0 && dist < 70) {
          e.fireCd -= dt;
          if (e.fireCd <= 0 && e.burst === 0) {
            e.burst = 3 + (Math.random() < 0.4 ? 1 : 0);
            e.burstT = 0;
            e.fireCd = 1.2 + Math.random() * 1.3;
          }
        }
      } else if (dist > 5) {
        mvx = dx / dist;
        mvz = dz / dist;
        spd = 4.3;
      }
      if (e.burst > 0) {
        e.burstT -= dt;
        if (e.burstT <= 0) {
          this.enemyFire(e, dist);
          e.burst--;
          e.burstT = 0.13;
        }
      }
      this.moveEnemy(e, mvx, mvz, spd, dt);
    } else {
      this.walkAI(e, dt);
    }

    // ноги и положение
    e.y = w.groundAt(e.x, e.z, e.y);
    e.walk += e.moving * dt * 2.3;
    const sw = Math.sin(e.walk) * 0.75 * clamp(e.moving / 2, 0, 1);
    e.legL.rotation.x = sw;
    e.legR.rotation.x = -sw;
    e.g.position.set(e.x, e.y + Math.abs(Math.sin(e.walk)) * 0.04 * clamp(e.moving / 2, 0, 1), e.z);
    e.g.rotation.y = e.yaw;
    e.shadow.position.set(e.x, e.y + 0.05, e.z);
  }

  private walkAI(e: Enemy, dt: number) {
    if (e.wait > 0) {
      e.wait -= dt;
      e.moving = 0;
      if (e.wait <= 0) {
        const a = Math.random() * Math.PI * 2;
        const r = 3 + Math.random() * 11;
        e.tx = e.homeX + Math.cos(a) * r;
        e.tz = e.homeZ + Math.sin(a) * r;
        e.hasT = true;
        e.walk = e.walk || 0;
        e.alertT = 6; // таймаут пути
      }
      return;
    }
    if (!e.hasT) {
      e.wait = 1 + Math.random() * 3;
      return;
    }
    const dx = e.tx - e.x;
    const dz = e.tz - e.z;
    const d = Math.hypot(dx, dz);
    e.alertT -= dt;
    if (d < 1 || e.alertT <= 0 || this.world.heightAt(e.tx, e.tz) < 0.3) {
      e.hasT = false;
      e.wait = 2 + Math.random() * 4;
      e.moving = 0;
      return;
    }
    const want = Math.atan2(dx, dz);
    e.yaw += clamp(wrapAngle(want - e.yaw), -4 * dt, 4 * dt);
    this.moveEnemy(e, dx / d, dz / d, 1.7, dt);
  }

  private moveEnemy(e: Enemy, mx: number, mz: number, spd: number, dt: number) {
    const w = this.world;
    if (spd <= 0) {
      e.moving = 0;
      return;
    }
    const pos = { x: e.x + mx * spd * dt, z: e.z + mz * spd * dt };
    if (w.heightAt(pos.x, pos.z) < -0.4) {
      e.moving = 0;
      return;
    }
    w.collide(pos, 0.45, e.y);
    // расталкивание
    for (const o of this.enemies) {
      if (o === e || o.state === 2) continue;
      const ox = pos.x - o.x;
      const oz = pos.z - o.z;
      const dd = ox * ox + oz * oz;
      if (dd < 0.64 && dd > 1e-6) {
        const d = Math.sqrt(dd);
        pos.x += (ox / d) * (0.8 - d) * 0.5;
        pos.z += (oz / d) * (0.8 - d) * 0.5;
      }
    }
    e.moving = Math.hypot(pos.x - e.x, pos.z - e.z) / dt;
    e.x = pos.x;
    e.z = pos.z;
  }

  private enemyFire(e: Enemy, dist: number) {
    const p = this.p;
    const ox = e.x + Math.sin(e.yaw) * 0.7;
    const oy = e.y + 1.25;
    const oz = e.z + Math.cos(e.yaw) * 0.7;
    const moving = p.speed > 2;
    const chance = clamp(0.82 - dist * 0.012, 0.14, 0.72) * (moving ? 0.72 : 1) * (this.adsT > 0.5 ? 0.88 : 1);
    const hit = Math.random() < chance;
    const target = new THREE.Vector3(p.x, p.y + 1.15, p.z);
    if (!hit) {
      const m = 0.6 + dist * 0.03;
      target.x += (Math.random() - 0.5) * 2 * m;
      target.y += (Math.random() - 0.5) * m;
      target.z += (Math.random() - 0.5) * 2 * m;
    }
    const from = new THREE.Vector3(ox, oy, oz);
    // трассер продолжаем чуть дальше цели
    const dirv = target.clone().sub(from).normalize();
    const to = hit ? target : target.clone().addScaledVector(dirv, 14);
    this.tracers.fire(from, to);
    this.tmpC.set('#ffd9a0');
    this.sparks.emit(ox, oy, oz, 0, 0, 0, 0.07, 0.5, this.tmpC, 0.9, 0);
    this.sfx.enemyShot(clamp(1 - dist / 110, 0.05, 1) * 0.65);
    if (hit) this.damagePlayer(4 + Math.random() * 4, e.x, e.z, true);
  }

  private damagePlayer(amount: number, sx: number, sz: number, directional: boolean) {
    const p = this.p;
    if (this.state !== 'playing') return;
    p.hp -= amount;
    this.hurtT = Math.min(1, this.hurtT + 0.55);
    if (this.time - this.lastHurtSfx > 0.3) {
      this.lastHurtSfx = this.time;
      this.sfx.hurt();
    }
    if (directional) {
      const ex = sx - p.x;
      const ez = sz - p.z;
      const l = Math.hypot(ex, ez) || 1;
      const fx = -Math.sin(p.yaw);
      const fz = -Math.cos(p.yaw);
      const rx = Math.cos(p.yaw);
      const rz = -Math.sin(p.yaw);
      const ang = Math.atan2((ex * rx + ez * rz) / l, (ex * fx + ez * fz) / l);
      this.onEvent({ type: 'hurt', angle: ang });
    } else this.onEvent({ type: 'hurt', angle: 0 });
  }

  // ---------------------------------------------------------------- предметы
  private updatePickups(dt: number) {
    const p = this.p;
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const pk = this.pickups[i];
      pk.t += dt;
      pk.g.rotation.y += dt * 1.5;
      pk.g.position.y = pk.y + 0.5 + Math.sin(pk.t * 2.5) * 0.1;
      const d = Math.hypot(pk.x - p.x, pk.z - p.z);
      if (d < 1.7 && Math.abs(pk.y - p.y) < 2) {
        let ok = false;
        if (pk.kind === 'med' && p.hp < 100) {
          p.hp = Math.min(100, p.hp + 40);
          ok = true;
        } else if (pk.kind === 'ammo' && p.reserve < 300) {
          p.reserve += 60;
          ok = true;
        }
        if (ok) {
          this.sfx.pickup();
          this.onEvent({ type: 'pickup', kind: pk.kind });
          this.world.scene.remove(pk.g);
          this.pickups.splice(i, 1);
        }
      }
    }
  }

  // ---------------------------------------------------------------- эффекты
  private blood(at: THREE.Vector3, d: THREE.Vector3) {
    for (let i = 0; i < 9; i++) {
      this.tmpC.set(i % 3 === 0 ? '#7a0d0d' : '#b01818');
      this.smoke.emit(at.x, at.y, at.z, -d.x * 1.5 + (Math.random() - 0.5) * 3, Math.random() * 2.2, -d.z * 1.5 + (Math.random() - 0.5) * 3, 0.45 + Math.random() * 0.3, 0.14 + Math.random() * 0.1, this.tmpC, 0.9, 9);
    }
  }

  private impact(at: THREE.Vector3, d: THREE.Vector3) {
    for (let i = 0; i < 5; i++) {
      this.tmpC.set('#ffb35c');
      this.sparks.emit(at.x, at.y, at.z, -d.x * 2 + (Math.random() - 0.5) * 5, Math.random() * 3.5, -d.z * 2 + (Math.random() - 0.5) * 5, 0.22 + Math.random() * 0.15, 0.11, this.tmpC, 1, 12);
    }
    for (let i = 0; i < 5; i++) {
      this.tmpC.set('#b9a77c');
      this.smoke.emit(at.x, at.y, at.z, (Math.random() - 0.5) * 1.6 - d.x, Math.random() * 1.2, (Math.random() - 0.5) * 1.6 - d.z, 0.6 + Math.random() * 0.4, 0.25, this.tmpC, 0.55, -0.4, 2.2);
    }
  }

  private splash(at: THREE.Vector3) {
    for (let i = 0; i < 9; i++) {
      this.tmpC.set('#dff6ff');
      this.smoke.emit(at.x, at.y, at.z, (Math.random() - 0.5) * 2.2, 2.5 + Math.random() * 3, (Math.random() - 0.5) * 2.2, 0.6 + Math.random() * 0.3, 0.2 + Math.random() * 0.12, this.tmpC, 0.85, 9, 0.6);
    }
  }

  private updateFx(dt: number) {
    this.sparks.update(dt);
    this.smoke.update(dt);
    this.tracers.update(dt);
  }

  private animateGun(dt: number, mv: number, sprint: boolean) {
    const p = this.p;
    const g = this.gunBase;
    const ads = this.adsT;
    // инерция от поворотов
    this.swayX = lerp(this.swayX, 0, dt * 6);
    this.swayY = lerp(this.swayY, 0, dt * 6);
    const rl = p.reloadT > 0 ? Math.sin(clamp(1 - p.reloadT / 1.9, 0, 1) * Math.PI) : 0;
    const sprintT = sprint && p.speed > 6 ? 1 : 0;
    const bx = Math.cos(p.bobT) * 0.012 * mv * (1 - ads * 0.85);
    const by = Math.abs(Math.sin(p.bobT)) * 0.012 * mv * (1 - ads * 0.85);
    const x = lerp(0.14, 0.0, ads) + bx + sprintT * 0.05;
    const y = lerp(-0.14, -0.088, ads) + by - rl * 0.12 - sprintT * 0.07;
    const z = lerp(-0.34, -0.26, ads) + p.kick * 0.035;
    g.position.set(x, y, z);
    g.rotation.set(p.kick * 0.045 - rl * 0.5 + sprintT * 0.15, sprintT * 0.5, -rl * 0.5 + bx * 2);

    if (this.flashT > 0) {
      this.flashT -= dt;
      this.flash.visible = true;
      const s = 0.2 + Math.random() * 0.14;
      this.flash.scale.set(s, s, 1);
      (this.flash.material as THREE.SpriteMaterial).rotation = Math.random() * 6.28;
      this.flashLight.intensity = 2.5;
    } else {
      this.flash.visible = false;
      this.flashLight.intensity = 0;
    }
  }

  // ---------------------------------------------------------------- миникарта
  private drawMap() {
    const cv = this.mapCanvas;
    if (!cv) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return;
    const S = cv.width;
    const range = 75;
    const k = S / 2 / range;
    const p = this.p;
    ctx.clearRect(0, 0, S, S);
    ctx.save();
    ctx.translate(S / 2, S / 2);
    ctx.rotate(p.yaw);
    ctx.scale(k, k);
    ctx.translate(-p.x, -p.z);
    ctx.drawImage(this.mapImg, -HALF, -HALF);
    for (const o of this.world.outposts) {
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.fillRect(o.x - 3, o.z - 3, 6, 6);
    }
    for (const e of this.enemies) {
      if (e.state === 2) continue;
      if (Math.hypot(e.x - p.x, e.z - p.z) > range * 1.1) continue;
      ctx.fillStyle = e.state === 1 ? '#ff2a2a' : '#ffb020';
      ctx.beginPath();
      ctx.arc(e.x, e.z, 2.6 / Math.max(k, 0.6) * 0.9, 0, 6.3);
      ctx.fill();
    }
    for (const pk of this.pickups) {
      ctx.fillStyle = pk.kind === 'med' ? '#ffffff' : '#ffe14d';
      ctx.fillRect(pk.x - 1.5, pk.z - 1.5, 3, 3);
    }
    ctx.restore();
    // игрок
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#0b1a2a';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(S / 2, S / 2 - 7);
    ctx.lineTo(S / 2 + 5, S / 2 + 5);
    ctx.lineTo(S / 2, S / 2 + 2);
    ctx.lineTo(S / 2 - 5, S / 2 + 5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.cleanup.forEach((f) => f());
    this.world.dispose();
    this.renderer.dispose();
    if (document.pointerLockElement) document.exitPointerLock();
  }
}
