// Чистые математические утилиты и генерация рельефа острова

export function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smoothstep = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

function hash(ix: number, iz: number) {
  let h = Math.imul(ix, 374761393) + Math.imul(iz, 668265263);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

export function vnoise(x: number, z: number) {
  const ix = Math.floor(x);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fz = z - iz;
  const u = fx * fx * (3 - 2 * fx);
  const v = fz * fz * (3 - 2 * fz);
  const a = hash(ix, iz);
  const b = hash(ix + 1, iz);
  const c = hash(ix, iz + 1);
  const d = hash(ix + 1, iz + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

// тайлящийся шум для текстуры деталей
export function tileNoise(x: number, z: number, period: number) {
  const ix = Math.floor(x);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fz = z - iz;
  const u = fx * fx * (3 - 2 * fx);
  const v = fz * fz * (3 - 2 * fz);
  const m = (n: number) => ((n % period) + period) % period;
  const a = hash(m(ix), m(iz));
  const b = hash(m(ix + 1), m(iz));
  const c = hash(m(ix), m(iz + 1));
  const d = hash(m(ix + 1), m(iz + 1));
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

export function fbm(x: number, z: number, oct = 4) {
  let a = 0.5;
  let f = 1;
  let s = 0;
  let n = 0;
  for (let i = 0; i < oct; i++) {
    s += a * vnoise(x * f, z * f);
    n += a;
    a *= 0.5;
    f *= 2.03;
  }
  return s / n;
}

export const WORLD = 400;
export const HALF = WORLD / 2;

export function baseHeight(x: number, z: number) {
  const w = fbm(x * 0.008 + 11, z * 0.008 + 3, 3);
  const d = (Math.hypot(x * 0.9, z * 1.05) / 200) * (1 + (0.5 - w) * 0.7);
  const shape = 1 - smoothstep(0.45, 1.0, d);
  const hills = fbm(x * 0.012, z * 0.012, 4);
  const mx = x - 15;
  const mz = z + 25;
  const mountain = 19 * Math.exp(-(mx * mx + mz * mz) / (2 * 34 * 34));
  const bumps = fbm(x * 0.06 + 5, z * 0.06 + 9, 2) * 1.6;
  return -7 + shape * (7.6 + 10 * Math.max(hills - 0.3, 0) + bumps + mountain * (0.6 + 0.4 * hills));
}
