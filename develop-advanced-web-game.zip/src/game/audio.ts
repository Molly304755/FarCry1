// Процедурный звук на WebAudio — никаких внешних файлов

export class Sfx {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  noiseBuf: AudioBuffer | null = null;
  enabled = true;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    try {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AC();
    } catch {
      return;
    }
    const ctx = this.ctx!;
    this.master = ctx.createGain();
    this.master.gain.value = 0.7;
    const comp = ctx.createDynamicsCompressor();
    this.master.connect(comp);
    comp.connect(ctx.destination);
    const len = ctx.sampleRate * 2;
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.startAmbient();
  }

  private startAmbient() {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 500;
    bp.Q.value = 0.4;
    const g = ctx.createGain();
    g.gain.value = 0.06;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.11;
    const lg = ctx.createGain();
    lg.gain.value = 0.045;
    lfo.connect(lg);
    lg.connect(g.gain);
    src.connect(bp);
    bp.connect(g);
    g.connect(this.master!);
    src.start();
    lfo.start();
  }

  private noise(vol: number, dur: number, f0: number, f1: number, type: BiquadFilterType = 'lowpass') {
    if (!this.ctx || !this.enabled || vol <= 0.002) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 0.8 + Math.random() * 0.4;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(f0, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(f1, 20), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.master!);
    src.start(t, Math.random(), dur + 0.05);
  }

  private tone(vol: number, dur: number, f0: number, f1: number, type: OscillatorType = 'sine', delay = 0) {
    if (!this.ctx || !this.enabled || vol <= 0.002) return;
    const ctx = this.ctx;
    const t = ctx.currentTime + delay;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(f1, 20), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g);
    g.connect(this.master!);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  shot(vol = 1) {
    this.noise(0.9 * vol, 0.16, 5200, 260);
    this.tone(0.7 * vol, 0.12, 170, 45, 'sine');
  }
  enemyShot(vol = 0.5) {
    this.noise(0.6 * vol, 0.2, 2600, 200);
    this.tone(0.4 * vol, 0.14, 120, 40, 'sine');
  }
  hit() {
    this.tone(0.25, 0.06, 1500, 1100, 'triangle');
  }
  headshot() {
    this.tone(0.3, 0.09, 2300, 1700, 'triangle');
    this.tone(0.2, 0.1, 900, 600, 'square', 0.02);
  }
  kill() {
    this.tone(0.25, 0.12, 700, 350, 'triangle');
  }
  hurt() {
    this.tone(0.6, 0.22, 110, 50, 'sine');
    this.noise(0.4, 0.15, 900, 150);
  }
  reload() {
    this.tone(0.15, 0.04, 900, 500, 'square');
    this.tone(0.15, 0.05, 600, 300, 'square', 0.55);
    this.tone(0.2, 0.06, 1000, 400, 'square', 1.35);
  }
  empty() {
    this.tone(0.12, 0.03, 1200, 800, 'square');
  }
  pickup() {
    this.tone(0.2, 0.1, 500, 900, 'sine');
    this.tone(0.2, 0.12, 800, 1300, 'sine', 0.08);
  }
  step() {
    this.noise(0.1, 0.07, 500, 150);
  }
  jump() {
    this.noise(0.08, 0.1, 700, 200);
  }
  win() {
    [0, 0.15, 0.3, 0.5].forEach((d, i) => this.tone(0.25, 0.4, 440 * Math.pow(1.26, i), 440 * Math.pow(1.26, i), 'triangle', d));
  }
  lose() {
    this.tone(0.4, 0.9, 220, 55, 'sawtooth');
  }
}
