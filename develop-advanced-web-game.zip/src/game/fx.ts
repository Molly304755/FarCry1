import * as THREE from 'three';

export class Particles {
  points: THREE.Points;
  max: number;
  pos: Float32Array;
  col: Float32Array;
  size: Float32Array;
  vel: Float32Array;
  life: Float32Array;
  maxLife: Float32Array;
  grav: Float32Array;
  a0: Float32Array;
  s0: Float32Array;
  grow: Float32Array;
  head = 0;
  alive = 0;
  geo: THREE.BufferGeometry;
  mat: THREE.ShaderMaterial;

  constructor(max: number, additive: boolean, uScale: { value: number }) {
    this.max = max;
    this.pos = new Float32Array(max * 3);
    this.col = new Float32Array(max * 4);
    this.size = new Float32Array(max);
    this.vel = new Float32Array(max * 3);
    this.life = new Float32Array(max);
    this.maxLife = new Float32Array(max).fill(1);
    this.grav = new Float32Array(max);
    this.a0 = new Float32Array(max);
    this.s0 = new Float32Array(max);
    this.grow = new Float32Array(max);
    this.geo = new THREE.BufferGeometry();
    const pa = new THREE.BufferAttribute(this.pos, 3);
    const ca = new THREE.BufferAttribute(this.col, 4);
    const sa = new THREE.BufferAttribute(this.size, 1);
    pa.setUsage(THREE.DynamicDrawUsage);
    ca.setUsage(THREE.DynamicDrawUsage);
    sa.setUsage(THREE.DynamicDrawUsage);
    this.geo.setAttribute('position', pa);
    this.geo.setAttribute('aColor', ca);
    this.geo.setAttribute('aSize', sa);
    this.mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
      uniforms: { uScale },
      vertexShader: `
        attribute vec4 aColor; attribute float aSize; uniform float uScale;
        varying vec4 vColor;
        void main(){
          vec4 mv = modelViewMatrix * vec4(position,1.0);
          gl_PointSize = min(aSize * uScale / max(-mv.z, 0.1), 160.0);
          gl_Position = projectionMatrix * mv;
          vColor = aColor;
        }`,
      fragmentShader: `
        varying vec4 vColor;
        void main(){
          vec2 c = gl_PointCoord - 0.5;
          float d = length(c) * 2.0;
          float a = smoothstep(1.0, 0.0, d);
          gl_FragColor = vec4(vColor.rgb, vColor.a * a * a);
          #include <colorspace_fragment>
        }`,
    });
    this.points = new THREE.Points(this.geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 10;
  }

  emit(x: number, y: number, z: number, vx: number, vy: number, vz: number, life: number, size: number, c: THREE.Color, a: number, grav: number, grow = 0) {
    const i = this.head;
    this.head = (this.head + 1) % this.max;
    this.pos[i * 3] = x;
    this.pos[i * 3 + 1] = y;
    this.pos[i * 3 + 2] = z;
    this.vel[i * 3] = vx;
    this.vel[i * 3 + 1] = vy;
    this.vel[i * 3 + 2] = vz;
    this.life[i] = life;
    this.maxLife[i] = life;
    this.s0[i] = size;
    this.a0[i] = a;
    this.grav[i] = grav;
    this.grow[i] = grow;
    this.col[i * 4] = c.r;
    this.col[i * 4 + 1] = c.g;
    this.col[i * 4 + 2] = c.b;
    this.col[i * 4 + 3] = a;
    this.size[i] = size;
    this.alive++;
  }

  update(dt: number) {
    if (this.alive <= 0) return;
    let any = 0;
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      if (this.life[i] <= 0) {
        this.size[i] = 0;
        continue;
      }
      any++;
      const t = this.life[i] / this.maxLife[i];
      this.vel[i * 3 + 1] -= this.grav[i] * dt;
      const drag = 1 - 1.8 * dt;
      this.vel[i * 3] *= drag;
      this.vel[i * 3 + 2] *= drag;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      this.col[i * 4 + 3] = this.a0[i] * t;
      this.size[i] = this.s0[i] * (1 + this.grow[i] * (1 - t));
    }
    this.alive = any;
    this.geo.attributes.position.needsUpdate = true;
    this.geo.attributes.aColor.needsUpdate = true;
    this.geo.attributes.aSize.needsUpdate = true;
  }
}

export class Tracers {
  meshes: THREE.Mesh[] = [];
  data: { from: THREE.Vector3; dir: THREE.Vector3; dist: number; age: number; on: boolean }[] = [];
  head = 0;
  geo: THREE.BoxGeometry;
  mat: THREE.MeshBasicMaterial;

  constructor(scene: THREE.Scene, n: number) {
    this.geo = new THREE.BoxGeometry(0.04, 0.04, 1);
    this.geo.translate(0, 0, 0.5);
    this.mat = new THREE.MeshBasicMaterial({ color: '#ffd27a', transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
    for (let i = 0; i < n; i++) {
      const m = new THREE.Mesh(this.geo, this.mat);
      m.visible = false;
      m.frustumCulled = false;
      scene.add(m);
      this.meshes.push(m);
      this.data.push({ from: new THREE.Vector3(), dir: new THREE.Vector3(), dist: 0, age: 0, on: false });
    }
  }

  fire(from: THREE.Vector3, to: THREE.Vector3) {
    const i = this.head;
    this.head = (this.head + 1) % this.meshes.length;
    const d = this.data[i];
    d.from.copy(from);
    d.dir.copy(to).sub(from);
    d.dist = d.dir.length();
    d.dir.divideScalar(d.dist || 1);
    d.age = 0;
    d.on = true;
    this.meshes[i].visible = true;
    this.meshes[i].position.copy(from);
    this.meshes[i].lookAt(to);
  }

  update(dt: number) {
    for (let i = 0; i < this.meshes.length; i++) {
      const d = this.data[i];
      if (!d.on) continue;
      d.age += dt;
      const headD = Math.min(d.dist, d.age * 320);
      const tailD = Math.max(0, headD - 9);
      if (tailD >= d.dist - 0.01) {
        d.on = false;
        this.meshes[i].visible = false;
        continue;
      }
      const m = this.meshes[i];
      m.position.copy(d.from).addScaledVector(d.dir, tailD);
      m.scale.set(1, 1, Math.max(0.05, headD - tailD));
    }
  }
}

export function softTexture(inner: string, outer: string, size = 64) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = size;
  const c = cv.getContext('2d')!;
  const g = c.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, inner);
  g.addColorStop(1, outer);
  c.fillStyle = g;
  c.fillRect(0, 0, size, size);
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function flashTexture() {
  const s = 128;
  const cv = document.createElement('canvas');
  cv.width = cv.height = s;
  const c = cv.getContext('2d')!;
  c.translate(s / 2, s / 2);
  const g = c.createRadialGradient(0, 0, 0, 0, 0, s / 2);
  g.addColorStop(0, 'rgba(255,255,230,1)');
  g.addColorStop(0.25, 'rgba(255,200,90,0.8)');
  g.addColorStop(1, 'rgba(255,120,20,0)');
  c.fillStyle = g;
  c.fillRect(-s / 2, -s / 2, s, s);
  c.fillStyle = 'rgba(255,230,160,0.9)';
  for (let i = 0; i < 6; i++) {
    c.rotate((Math.PI * 2) / 6);
    c.beginPath();
    c.moveTo(0, -3);
    c.lineTo(s / 2 - 4, 0);
    c.lineTo(0, 3);
    c.fill();
  }
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
