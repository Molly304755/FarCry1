import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { HALF, WORLD, baseHeight, clamp, fbm, lerp, mulberry32, smoothstep, tileNoise } from './noise';

export interface QualityCfg {
  name: string;
  cap: number; // максимум pixelRatio
  minScale: number;
  segs: number;
  density: number;
  fogFar: number;
  aa: boolean;
}

export const QUALITY: Record<string, QualityCfg> = {
  low: { name: 'Низкое', cap: 0.9, minScale: 0.55, segs: 110, density: 0.55, fogFar: 230, aa: false },
  med: { name: 'Среднее', cap: 1.25, minScale: 0.5, segs: 150, density: 0.8, fogFar: 290, aa: false },
  high: { name: 'Высокое', cap: 1.75, minScale: 0.5, segs: 190, density: 1, fogFar: 350, aa: true },
  ultra: { name: 'Ультра', cap: 2.5, minScale: 0.5, segs: 240, density: 1.2, fogFar: 430, aa: true },
};

export interface Obstacle {
  kind: 0 | 1; // 0 круг, 1 прямоугольник
  x: number;
  z: number;
  r: number;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  top: number;
}

export interface Outpost {
  x: number;
  z: number;
  h: number;
}

const CELL = 12;
const GN = Math.ceil(WORLD / CELL) + 1;
const GRID = WORLD + 1;

export const FOG_COLOR = '#c4e6ee';
export const SUN_DIR = new THREE.Vector3(0.55, 0.62, -0.45).normalize();

function paint(g: THREE.BufferGeometry, color: THREE.Color | string, shade?: (y: number) => number) {
  const c = new THREE.Color(color);
  g.deleteAttribute('uv');
  const pos = g.attributes.position;
  const arr = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    const s = shade ? shade(pos.getY(i)) : 1;
    arr[i * 3] = c.r * s;
    arr[i * 3 + 1] = c.g * s;
    arr[i * 3 + 2] = c.b * s;
  }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return g;
}

function ng(g: THREE.BufferGeometry) {
  return g.index ? g.toNonIndexed() : g;
}

function addSway(mat: THREE.Material, uTime: { value: number }, amp: number) {
  mat.customProgramCacheKey = () => 'sway' + amp;
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = uTime;
    sh.vertexShader =
      'uniform float uTime;\n' +
      sh.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        #ifdef USE_INSTANCING
        float ph = instanceMatrix[3].x*0.21 + instanceMatrix[3].z*0.17;
        float sw = sin(uTime*1.6 + ph) + 0.5*sin(uTime*2.9 + ph*1.7);
        float rad = length(position.xz);
        transformed.x += sw * ${amp.toFixed(3)} * (rad*0.5 + max(position.y,0.0)*0.2);
        transformed.z += cos(uTime*1.3+ph) * ${amp.toFixed(3)} * 0.6 * rad*0.5;
        #endif`
      );
  };
}

export class World {
  scene = new THREE.Scene();
  heights = new Float32Array(GRID * GRID);
  obstacles: Obstacle[] = [];
  cells: Obstacle[][] = [];
  outposts: Outpost[] = [];
  spawn = { x: 0, z: 110 };
  uTime = { value: 0 };
  sky!: THREE.Mesh;
  clouds: { s: THREE.Sprite; a: number; r: number; y: number; sp: number }[] = [];
  waterMat!: THREE.ShaderMaterial;
  cfg: QualityCfg;
  disposables: { dispose(): void }[] = [];

  constructor(cfg: QualityCfg) {
    this.cfg = cfg;
    for (let i = 0; i < GN * GN; i++) this.cells.push([]);
    this.scene.background = new THREE.Color(FOG_COLOR);
    this.scene.fog = new THREE.Fog(FOG_COLOR, 55, cfg.fogFar);
    this.pickOutposts();
    this.bakeHeights();
    this.findSpawn();
    this.addLights();
    this.addSky();
    this.addTerrainAndPlants();
    this.addOutposts();
    this.addWater();
    this.addFarIslands();
    this.buildCells();
  }

  // ---------- рельеф ----------
  private pickOutposts() {
    const rng = mulberry32(4242);
    let tries = 0;
    while (this.outposts.length < 4 && tries < 1500) {
      tries++;
      const a = rng() * Math.PI * 2;
      const r = 25 + rng() * 95;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      const h = baseHeight(x, z);
      if (h < 2.3 || h > 8.5) continue;
      const s = Math.abs(baseHeight(x + 9, z) - h) + Math.abs(baseHeight(x, z + 9) - h) + Math.abs(baseHeight(x - 9, z) - h) + Math.abs(baseHeight(x, z - 9) - h);
      if (s > 5.5) continue;
      if (Math.hypot(x - 0, z - 110) < 75) continue;
      if (this.outposts.some((o) => Math.hypot(o.x - x, o.z - z) < 80)) continue;
      this.outposts.push({ x, z, h });
    }
  }

  private bakeHeights() {
    for (let gz = 0; gz < GRID; gz++) {
      for (let gx = 0; gx < GRID; gx++) {
        const x = gx - HALF;
        const z = gz - HALF;
        let h = baseHeight(x, z);
        for (const o of this.outposts) {
          const d = Math.hypot(x - o.x, z - o.z);
          if (d < 34) h = lerp(h, o.h, 1 - smoothstep(17, 34, d));
        }
        this.heights[gz * GRID + gx] = h;
      }
    }
  }

  heightAt(x: number, z: number) {
    const fx = clamp(x + HALF, 0, WORLD - 0.001);
    const fz = clamp(z + HALF, 0, WORLD - 0.001);
    const ix = fx | 0;
    const iz = fz | 0;
    const u = fx - ix;
    const v = fz - iz;
    const i = iz * GRID + ix;
    const H = this.heights;
    const a = H[i];
    const b = H[i + 1];
    const c = H[i + GRID];
    const d = H[i + GRID + 1];
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }

  slopeAt(x: number, z: number) {
    const dx = this.heightAt(x + 1.5, z) - this.heightAt(x - 1.5, z);
    const dz = this.heightAt(x, z + 1.5) - this.heightAt(x, z - 1.5);
    return Math.hypot(dx, dz) / 3;
  }

  private findSpawn() {
    for (let z = 190; z > -50; z -= 1) {
      if (this.heightAt(0, z) > 0.9) {
        this.spawn = { x: 0, z: z - 2 };
        break;
      }
    }
  }

  // ---------- свет/небо ----------
  private addLights() {
    const hemi = new THREE.HemisphereLight('#bfe6ff', '#7d8a55', 2.0);
    this.scene.add(hemi);
    const sun = new THREE.DirectionalLight('#fff0d0', 3.6);
    sun.position.copy(SUN_DIR).multiplyScalar(100);
    this.scene.add(sun);
  }

  private addSky() {
    const geo = new THREE.SphereGeometry(500, 24, 14);
    const mat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        uSun: { value: SUN_DIR.clone() },
        uZenith: { value: new THREE.Color('#2b86d6') },
        uMid: { value: new THREE.Color('#78c0ee') },
        uHorizon: { value: new THREE.Color(FOG_COLOR) },
        uSunCol: { value: new THREE.Color('#ffe9b0') },
      },
      vertexShader: `
        varying vec3 vDir;
        void main(){
          vDir = position;
          vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0);
          gl_Position = p.xyww;
        }`,
      fragmentShader: `
        uniform vec3 uSun, uZenith, uMid, uHorizon, uSunCol;
        varying vec3 vDir;
        void main(){
          vec3 d = normalize(vDir);
          float h = d.y;
          float t = clamp(h,0.0,1.0);
          vec3 col = mix(uHorizon, uMid, smoothstep(0.0,0.22,t));
          col = mix(col, uZenith, smoothstep(0.15,0.9,t));
          float s = max(dot(d,uSun),0.0);
          col += uSunCol * (pow(s,1200.0)*5.0 + pow(s,60.0)*0.45 + pow(s,7.0)*0.14);
          col = mix(col, uHorizon, smoothstep(0.01,-0.08,h));
          gl_FragColor = vec4(col,1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
    });
    this.sky = new THREE.Mesh(geo, mat);
    this.sky.renderOrder = -100;
    this.sky.frustumCulled = false;
    this.scene.add(this.sky);
    this.disposables.push(geo, mat);

    // облака
    const cv = document.createElement('canvas');
    cv.width = 256;
    cv.height = 128;
    const cx = cv.getContext('2d')!;
    const rng = mulberry32(9);
    for (let i = 0; i < 26; i++) {
      const x = 50 + rng() * 156;
      const y = 50 + rng() * 40 - Math.abs(x - 128) * 0.15;
      const r = 18 + rng() * 26;
      const g = cx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, 'rgba(255,255,255,0.55)');
      g.addColorStop(0.6, 'rgba(255,255,255,0.2)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      cx.fillStyle = g;
      cx.fillRect(x - r, y - r, r * 2, r * 2);
    }
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    const sm = new THREE.SpriteMaterial({ map: tex, fog: false, depthWrite: false, transparent: true, opacity: 0.95 });
    this.disposables.push(tex, sm);
    const n = this.cfg.density < 0.7 ? 8 : 14;
    for (let i = 0; i < n; i++) {
      const s = new THREE.Sprite(sm);
      const w = 220 + rng() * 200;
      s.scale.set(w, w * 0.5, 1);
      s.renderOrder = -90;
      this.scene.add(s);
      this.clouds.push({ s, a: rng() * Math.PI * 2, r: 360 + rng() * 80, y: 70 + rng() * 90, sp: 0.0006 + rng() * 0.0008 });
    }
  }

  private addFarIslands() {
    const mat = new THREE.MeshBasicMaterial({ vertexColors: true, fog: false });
    this.disposables.push(mat);
    const rng = mulberry32(31);
    for (let i = 0; i < 5; i++) {
      const ang = (i / 5) * Math.PI * 2 + rng() * 0.8;
      const dist = 560 + rng() * 120;
      const geo = new THREE.ConeGeometry(70 + rng() * 80, 40 + rng() * 60, 9, 1);
      const p = geo.attributes.position;
      for (let k = 0; k < p.count; k++) {
        p.setX(k, p.getX(k) + (rng() - 0.5) * 12);
        p.setZ(k, p.getZ(k) + (rng() - 0.5) * 12);
      }
      geo.computeVertexNormals();
      const top = new THREE.Color('#7fb3a8');
      const bot = new THREE.Color(FOG_COLOR);
      paint(geo, top);
      const col = geo.attributes.color;
      const h = geo.parameters.height;
      for (let k = 0; k < col.count; k++) {
        const t = clamp((p.getY(k) + h / 2) / h, 0, 1);
        const c = bot.clone().lerp(top, 0.25 + 0.65 * t);
        col.setXYZ(k, c.r, c.g, c.b);
      }
      const m = new THREE.Mesh(geo, mat);
      m.position.set(Math.cos(ang) * dist, h / 2 - 12, Math.sin(ang) * dist);
      m.frustumCulled = false;
      this.scene.add(m);
      this.disposables.push(geo);
    }
  }

  // ---------- вода ----------
  private addWater() {
    const D = 256;
    const data = new Uint8Array(D * D * 4);
    for (let j = 0; j < D; j++) {
      for (let i = 0; i < D; i++) {
        const x = (i / (D - 1)) * WORLD - HALF;
        const z = (j / (D - 1)) * WORLD - HALF;
        const h = this.heightAt(x, z);
        const v = clamp(-h / 6, 0, 1);
        const k = (j * D + i) * 4;
        data[k] = v * 255;
        data[k + 1] = data[k + 2] = 0;
        data[k + 3] = 255;
      }
    }
    const tex = new THREE.DataTexture(data, D, D, THREE.RGBAFormat);
    tex.magFilter = THREE.LinearFilter;
    tex.minFilter = THREE.LinearFilter;
    tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.needsUpdate = true;
    const mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: {
        uTime: this.uTime,
        uDepth: { value: tex },
        uSun: { value: SUN_DIR.clone() },
        uShallow: { value: new THREE.Color('#58e6d2') },
        uDeep: { value: new THREE.Color('#0a5f9e') },
        uSky: { value: new THREE.Color('#8fcbf0') },
        uFog: { value: new THREE.Color(FOG_COLOR) },
        uFogNear: { value: 55 },
        uFogFar: { value: this.cfg.fogFar },
      },
      vertexShader: `
        varying vec3 vWorld;
        void main(){
          vec4 wp = modelMatrix * vec4(position,1.0);
          vWorld = wp.xyz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }`,
      fragmentShader: `
        uniform float uTime, uFogNear, uFogFar;
        uniform sampler2D uDepth;
        uniform vec3 uSun, uShallow, uDeep, uSky, uFog;
        varying vec3 vWorld;
        void main(){
          vec2 uv = (vWorld.xz + 200.0)/400.0;
          float dep = texture2D(uDepth, uv).r;
          vec2 p = vWorld.xz; float t = uTime;
          float nx = cos(p.x*0.8+t*1.4)*0.06 + cos(p.x*1.7+p.y*1.3 - t*2.0)*0.04 + cos(p.x*3.1 - p.y*2.3 + t*2.7)*0.025;
          float nz = cos(p.y*0.9-t*1.2)*0.06 + cos(p.y*1.9 - p.x*1.1 + t*1.8)*0.04 + cos(p.y*3.3+p.x*2.1 - t*2.4)*0.025;
          vec3 n = normalize(vec3(-nx,1.0,-nz));
          vec3 V = cameraPosition - vWorld; float dist = length(V); V /= dist;
          float fres = pow(1.0 - max(dot(n,V),0.0), 4.0);
          vec3 col = mix(uShallow, uDeep, smoothstep(0.0,0.75,dep));
          col = mix(col, uSky, clamp(0.10 + fres*0.8, 0.0, 1.0));
          vec3 H = normalize(uSun + V);
          float spec = pow(max(dot(n,H),0.0), 200.0) * 2.6;
          col += vec3(1.0,0.95,0.8) * spec;
          float wob = 0.035*sin(t*1.3 + p.x*0.25 + p.y*0.2) + 0.02*sin(t*2.1 + p.y*0.6);
          float shore = smoothstep(0.075, 0.0, dep + wob - 0.012);
          float stripes = 0.5 + 0.5*sin((dep+wob)*110.0 - t*1.8);
          float foam = shore * (0.55 + 0.45*stripes);
          float foam2 = smoothstep(0.014, 0.0, abs(dep + wob - 0.075)) * 0.5;
          float f = clamp(foam + foam2, 0.0, 1.0);
          col = mix(col, vec3(1.0), f);
          float alpha = mix(0.38, 0.96, smoothstep(0.0, 0.35, dep));
          alpha = max(alpha, f);
          float ff = smoothstep(uFogNear, uFogFar, dist);
          col = mix(col, uFog, ff);
          alpha = mix(alpha, 1.0, ff);
          gl_FragColor = vec4(col, alpha);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
    });
    this.waterMat = mat;
    const geo = new THREE.PlaneGeometry(2600, 2600, 1, 1);
    geo.rotateX(-Math.PI / 2);
    const m = new THREE.Mesh(geo, mat);
    m.position.y = -0.02;
    m.renderOrder = 5;
    m.frustumCulled = false;
    this.scene.add(m);
    this.disposables.push(tex, mat, geo);
  }

  // ---------- террейн и растения ----------
  private addTerrainAndPlants() {
    const rng = mulberry32(777);
    const cfg = this.cfg;
    const d = cfg.density;
    type Inst = { x: number; y: number; z: number; s: number; ry: number; extra: number };
    const palms: Inst[] = [];
    const broads: Inst[] = [];
    const bushes: Inst[] = [];
    const rocks: Inst[] = [];
    const occ = new Uint8Array(200 * 200);
    const taken = (x: number, z: number) => {
      const ix = Math.floor((x + HALF) / 2);
      const iz = Math.floor((z + HALF) / 2);
      const k = iz * 200 + ix;
      if (occ[k]) return true;
      occ[k] = 1;
      return false;
    };
    const nearOutpost = (x: number, z: number, r: number) => this.outposts.some((o) => Math.hypot(o.x - x, o.z - z) < r);
    const maxP = Math.floor(330 * d);
    const maxB = Math.floor(300 * d);
    const maxBu = Math.floor(520 * d);
    const maxR = Math.floor(100 * d);
    const trees: { x: number; z: number; r: number }[] = [];

    for (let i = 0; i < 16000; i++) {
      if (palms.length >= maxP && broads.length >= maxB && bushes.length >= maxBu && rocks.length >= maxR) break;
      const x = (rng() * 2 - 1) * 175;
      const z = (rng() * 2 - 1) * 175;
      const h = this.heightAt(x, z);
      const r = rng();
      if (h < 0.5) continue;
      if (nearOutpost(x, z, 17) || Math.hypot(x - this.spawn.x, z - this.spawn.z) < 9) continue;
      const slope = this.slopeAt(x, z);
      const dens = fbm(x * 0.035 + 50, z * 0.035 + 20, 3);
      if (h < 6 && slope < 0.7 && dens > 0.3 && r < 0.6 && palms.length < maxP) {
        if (taken(x, z)) continue;
        palms.push({ x, y: h, z, s: 0.8 + rng() * 0.6, ry: rng() * 6.28, extra: rng() });
        trees.push({ x, z, r: 3 });
      } else if (h > 2.4 && h < 15 && slope < 0.85 && dens > 0.4 && r < 0.75 && broads.length < maxB) {
        if (taken(x, z)) continue;
        broads.push({ x, y: h, z, s: 0.85 + rng() * 0.6, ry: rng() * 6.28, extra: rng() });
        trees.push({ x, z, r: 4.2 });
      } else if (r > 0.55 && slope < 1.1 && h < 17 && bushes.length < maxBu) {
        bushes.push({ x, y: h, z, s: 0.6 + rng() * 0.9, ry: rng() * 6.28, extra: rng() });
      } else if ((slope > 0.55 || h > 9 || r < 0.03) && rocks.length < maxR && r < 0.4) {
        rocks.push({ x, y: h, z, s: 0.6 + rng() * 1.6, ry: rng() * 6.28, extra: rng() });
      }
    }

    // --- меш террейна ---
    const segs = cfg.segs;
    const geo = new THREE.PlaneGeometry(WORLD, WORLD, segs, segs);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position;
    const colors = new Float32Array(pos.count * 3);
    const C = (h: string) => new THREE.Color(h);
    const sandWet = C('#a8946c'), sand = C('#ead9a4'), grassL = C('#86b94a'), grassM = C('#55953a'), jungle = C('#2f6e2c'), rock = C('#7f7b72'), rockHi = C('#b3afa4'), dirt = C('#9b7d55');
    const tmp = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const h = this.heightAt(x, z);
      pos.setY(i, h);
      const sl = this.slopeAt(x, z);
      const n = fbm(x * 0.07, z * 0.07, 3);
      const n2 = fbm(x * 0.02 + 30, z * 0.02, 3);
      if (h < 0.1) tmp.copy(sandWet).lerp(sand, smoothstep(-3, 0.1, h) * 0.6);
      else tmp.copy(sandWet).lerp(sand, smoothstep(0.1, 0.7, h));
      const gT = smoothstep(1.3 + n * 1.4, 2.6 + n * 1.4, h);
      if (gT > 0) {
        const g = tmp.clone();
        g.copy(grassL).lerp(grassM, n2);
        g.lerp(jungle, smoothstep(3, 8, h) * (0.4 + 0.6 * n2));
        tmp.lerp(g, gT);
      }
      for (const o of this.outposts) {
        const dd = Math.hypot(x - o.x, z - o.z);
        if (dd < 24) tmp.lerp(dirt, (1 - smoothstep(10, 24, dd)) * (0.55 + n * 0.45));
      }
      const rT = Math.max(smoothstep(0.7, 1.15, sl), smoothstep(12, 18, h));
      if (rT > 0) tmp.lerp(rock.clone().lerp(rockHi, smoothstep(14, 22, h)), rT);
      colors[i * 3] = tmp.r;
      colors[i * 3 + 1] = tmp.g;
      colors[i * 3 + 2] = tmp.b;
    }
    // «запечённая» тень от деревьев
    const sp = WORLD / segs;
    for (const t of trees) {
      const cx = Math.round((t.x + HALF) / sp);
      const cz = Math.round((t.z + HALF) / sp);
      const rr = Math.ceil(t.r / sp) + 1;
      for (let dz = -rr; dz <= rr; dz++) {
        for (let dx = -rr; dx <= rr; dx++) {
          const ix = cx + dx;
          const iz = cz + dz;
          if (ix < 0 || iz < 0 || ix > segs || iz > segs) continue;
          const dist = Math.hypot(ix * sp - HALF - t.x, iz * sp - HALF - t.z);
          const f = 1 - smoothstep(0.5, t.r, dist);
          if (f <= 0) continue;
          const k = (iz * (segs + 1) + ix) * 3;
          const m = 1 - 0.45 * f;
          colors[k] *= m;
          colors[k + 1] *= m;
          colors[k + 2] *= m;
        }
      }
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();

    // текстура деталей
    const DS = 256;
    const dd = new Uint8Array(DS * DS * 4);
    for (let j = 0; j < DS; j++) {
      for (let i = 0; i < DS; i++) {
        const u = i / DS;
        const v = j / DS;
        const val = tileNoise(u * 8, v * 8, 8) * 0.45 + tileNoise(u * 24, v * 24, 24) * 0.35 + tileNoise(u * 64, v * 64, 64) * 0.2;
        const k = (j * DS + i) * 4;
        dd[k] = dd[k + 1] = dd[k + 2] = clamp(val, 0, 1) * 255;
        dd[k + 3] = 255;
      }
    }
    const detail = new THREE.DataTexture(dd, DS, DS, THREE.RGBAFormat);
    detail.wrapS = detail.wrapT = THREE.RepeatWrapping;
    detail.magFilter = THREE.LinearFilter;
    detail.minFilter = THREE.LinearMipmapLinearFilter;
    detail.generateMipmaps = true;
    detail.anisotropy = 2;
    detail.needsUpdate = true;
    const tmat = new THREE.MeshLambertMaterial({ vertexColors: true });
    tmat.onBeforeCompile = (sh) => {
      sh.uniforms.uDetail = { value: detail };
      sh.vertexShader = 'varying vec2 vDetUv;\n' + sh.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\n vDetUv = position.xz;');
      sh.fragmentShader =
        'varying vec2 vDetUv; uniform sampler2D uDetail;\n' +
        sh.fragmentShader.replace(
          '#include <color_fragment>',
          `#include <color_fragment>
           float d1 = texture2D(uDetail, vDetUv*0.23).r;
           float d2 = texture2D(uDetail, vDetUv*0.037+0.3).r;
           diffuseColor.rgb *= 0.45 + d1*0.65 + d2*0.5;`
        );
    };
    const terrain = new THREE.Mesh(geo, tmat);
    this.scene.add(terrain);
    this.disposables.push(geo, tmat, detail);

    // --- растительность ---
    const mk = (geom: THREE.BufferGeometry, mat: THREE.Material, list: Inst[], place: (i: Inst, m: THREE.Matrix4, c: THREE.Color) => void) => {
      if (!list.length) return;
      const im = new THREE.InstancedMesh(geom, mat, list.length);
      const m = new THREE.Matrix4();
      const c = new THREE.Color();
      list.forEach((it, i) => {
        place(it, m, c);
        im.setMatrixAt(i, m);
        im.setColorAt(i, c);
      });
      im.instanceMatrix.needsUpdate = true;
      if (im.instanceColor) im.instanceColor.needsUpdate = true;
      im.frustumCulled = false;
      this.scene.add(im);
      this.disposables.push(geom, mat);
    };

    const q = new THREE.Quaternion();
    const e = new THREE.Euler();
    const v3 = new THREE.Vector3();
    const sc = new THREE.Vector3();

    // пальмы
    const trunkGeo = paint(ng(new THREE.CylinderGeometry(0.1, 0.21, 1, 6, 1, true).translate(0, 0.5, 0)), '#ffffff');
    const trunkMat = new THREE.MeshLambertMaterial({ vertexColors: true, color: '#9c7a52' });
    const crownGeo = this.palmCrown();
    const leafMat = new THREE.MeshLambertMaterial({ side: THREE.DoubleSide, vertexColors: true });
    addSway(leafMat, this.uTime, 0.05);
    const tips: THREE.Vector3[] = [];
    mk(trunkGeo, trunkMat, palms, (it, m, c) => {
      const h = (5.5 + it.extra * 4) * it.s;
      e.set((it.extra - 0.5) * 0.3, it.ry, (rng() - 0.5) * 0.3);
      q.setFromEuler(e);
      v3.set(0, h, 0).applyQuaternion(q);
      tips.push(new THREE.Vector3(it.x + v3.x, it.y + v3.y, it.z + v3.z));
      m.compose(new THREE.Vector3(it.x, it.y - 0.2, it.z), q, sc.set(it.s, h, it.s));
      c.set('#ffffff');
      this.obstacles.push(this.circle(it.x, it.z, 0.3, it.y + h));
    });
    let pi = 0;
    mk(crownGeo, leafMat, palms, (it, m, c) => {
      const t = tips[pi++];
      m.compose(t, q.setFromEuler(e.set(0, it.ry, 0)), sc.set(it.s * 1.15, it.s * 1.15, it.s * 1.15));
      c.set('#3f9c35').lerp(new THREE.Color('#79b83c'), it.extra);
    });

    // широколиственные
    const bTrunkGeo = paint(ng(new THREE.CylinderGeometry(0.22, 0.42, 1, 7, 1, true).translate(0, 0.5, 0)), '#ffffff');
    const bTrunkMat = new THREE.MeshLambertMaterial({ vertexColors: true, color: '#6e5238' });
    const bCrownGeo = this.broadCrown();
    const bLeafMat = new THREE.MeshLambertMaterial({ vertexColors: true });
    addSway(bLeafMat, this.uTime, 0.018);
    const bh: number[] = [];
    mk(bTrunkGeo, bTrunkMat, broads, (it, m, c) => {
      const h = (4.5 + it.extra * 3) * it.s;
      bh.push(h);
      m.compose(v3.set(it.x, it.y - 0.3, it.z), q.identity(), sc.set(it.s, h, it.s));
      c.set('#ffffff');
      this.obstacles.push(this.circle(it.x, it.z, 0.55 * it.s, it.y + h + 3));
    });
    let bi = 0;
    mk(bCrownGeo, bLeafMat, broads, (it, m, c) => {
      const h = bh[bi++];
      m.compose(v3.set(it.x, it.y + h, it.z), q.setFromEuler(e.set(0, it.ry, 0)), sc.set(it.s, it.s * 0.9, it.s));
      c.set('#2a7a30').lerp(new THREE.Color('#58a23a'), it.extra);
    });

    // кусты
    const bushGeo = paint(ng(new THREE.IcosahedronGeometry(0.8, 1)), '#ffffff', (y) => 0.55 + 0.6 * clamp((y + 0.8) / 1.6, 0, 1));
    const bushMat = new THREE.MeshLambertMaterial({ vertexColors: true });
    addSway(bushMat, this.uTime, 0.03);
    mk(bushGeo, bushMat, bushes, (it, m, c) => {
      m.compose(v3.set(it.x, it.y + 0.25 * it.s, it.z), q.setFromEuler(e.set(0, it.ry, 0)), sc.set(it.s * 1.3, it.s * 0.85, it.s * 1.3));
      c.set('#3f8f35').lerp(new THREE.Color('#78b441'), it.extra);
    });

    // камни
    const rg = new THREE.DodecahedronGeometry(1, 0);
    const rp = rg.attributes.position;
    const rr = mulberry32(5);
    const seen = new Map<string, THREE.Vector3>();
    for (let i = 0; i < rp.count; i++) {
      const k = `${rp.getX(i).toFixed(3)},${rp.getY(i).toFixed(3)},${rp.getZ(i).toFixed(3)}`;
      let o = seen.get(k);
      if (!o) {
        o = new THREE.Vector3(1 + (rr() - 0.5) * 0.35, 1 + (rr() - 0.5) * 0.35, 1 + (rr() - 0.5) * 0.35);
        seen.set(k, o);
      }
      rp.setXYZ(i, rp.getX(i) * o.x, rp.getY(i) * o.y * 0.8, rp.getZ(i) * o.z);
    }
    rg.computeVertexNormals();
    const rockGeo = paint(ng(rg), '#ffffff', (y) => 0.7 + 0.4 * clamp((y + 1) / 2, 0, 1));
    const rockMat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true });
    mk(rockGeo, rockMat, rocks, (it, m, c) => {
      m.compose(v3.set(it.x, it.y + 0.2 * it.s, it.z), q.setFromEuler(e.set(0, it.ry, 0)), sc.set(it.s * 1.2, it.s, it.s * 1.1));
      c.set('#8b8981').lerp(new THREE.Color('#aaa59a'), it.extra);
      this.obstacles.push(this.circle(it.x, it.z, it.s * 1.0, it.y + it.s * 0.9));
    });
  }

  private circle(x: number, z: number, r: number, top: number): Obstacle {
    return { kind: 0, x, z, r, minX: x - r, maxX: x + r, minZ: z - r, maxZ: z + r, top };
  }

  private box(minX: number, maxX: number, minZ: number, maxZ: number, top: number): Obstacle {
    return { kind: 1, x: (minX + maxX) / 2, z: (minZ + maxZ) / 2, r: 0, minX, maxX, minZ, maxZ, top };
  }

  private palmCrown() {
    const leaves = 9;
    const segs = 6;
    const pos: number[] = [];
    const col: number[] = [];
    const idx: number[] = [];
    for (let i = 0; i < leaves; i++) {
      const a = (i / leaves) * Math.PI * 2 + Math.sin(i * 7.3) * 0.2;
      const L = 3.4 + Math.sin(i * 3.1) * 0.5;
      const ox = Math.cos(a);
      const oz = Math.sin(a);
      const px = -oz;
      const pz = ox;
      const base = pos.length / 3;
      for (let s = 0; s <= segs; s++) {
        const t = s / segs;
        const rad = t * L;
        const y = 0.9 * t - 1.9 * t * t + 0.15;
        const w = 0.6 * Math.sin(Math.PI * Math.min(1, t * 1.05 + 0.04)) * (1 - t * 0.25) + 0.02;
        const shade = 0.65 + 0.5 * t * (1 - t) * 3;
        // гребень листа слегка приподнят
        pos.push(ox * rad + px * w, y - 0.12 * w, oz * rad + pz * w);
        pos.push(ox * rad - px * w, y - 0.12 * w, oz * rad - pz * w);
        for (let k = 0; k < 2; k++) col.push(shade, shade, shade);
      }
      for (let s = 0; s < segs; s++) {
        const k = base + s * 2;
        idx.push(k, k + 1, k + 2, k + 1, k + 3, k + 2);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.setIndex(idx);
    g.computeVertexNormals();
    return g;
  }

  private broadCrown() {
    const parts: THREE.BufferGeometry[] = [];
    const offs = [
      [0, 0.8, 0, 2.3],
      [1.4, 0.2, 0.6, 1.7],
      [-1.3, 0.4, -0.5, 1.8],
      [0.2, 1.7, -0.9, 1.6],
      [-0.4, 0.3, 1.4, 1.6],
    ];
    for (const [x, y, z, r] of offs) {
      const g = new THREE.IcosahedronGeometry(r, 1);
      const p = g.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const k = Math.sin(p.getX(i) * 3.1 + p.getZ(i) * 2.3 + p.getY(i) * 1.7) * 0.18;
        p.setXYZ(i, p.getX(i) * (1 + k), p.getY(i) * (1 + k * 0.5), p.getZ(i) * (1 + k));
      }
      g.translate(x, y, z);
      g.computeVertexNormals();
      paint(g, '#ffffff', (yy) => 0.5 + 0.65 * clamp((yy + 1.2) / 4, 0, 1));
      parts.push(g);
    }
    return mergeGeometries(parts)!;
  }

  // ---------- аванпосты ----------
  private addOutposts() {
    const parts: THREE.BufferGeometry[] = [];
    const rng = mulberry32(555);
    const add = (g: THREE.BufferGeometry, color: string, x: number, y: number, z: number, ry = 0, shade?: (y: number) => number) => {
      const gg = ng(g);
      paint(gg, color, shade);
      if (ry) gg.rotateY(ry);
      gg.translate(x, y, z);
      parts.push(gg);
    };
    const bx = (cx: number, cy: number, cz: number, sx: number, sy: number, sz: number, color: string, ry = 0) => {
      add(new THREE.BoxGeometry(sx, sy, sz), color, cx, cy + sy / 2, cz, ry, (y) => 0.8 + 0.3 * clamp((y + sy / 2) / sy, 0, 1));
    };
    const wood = ['#b68b55', '#a97f4b', '#c29a62'];

    for (const o of this.outposts) {
      const { x: ox, z: oz, h } = o;
      const hut = (dx: number, dz: number, w: number, d: number, hh: number, wc: string, rc: string, doorSide: number) => {
        const cx = ox + dx;
        const cz = oz + dz;
        bx(cx, h, cz, w, hh, d, wc);
        // крыша
        const roof = new THREE.ConeGeometry(1, 1.8, 4, 1);
        roof.rotateY(Math.PI / 4);
        roof.scale((w / Math.SQRT2) * 1.18, 1, (d / Math.SQRT2) * 1.18);
        roof.computeVertexNormals();
        add(roof, rc, cx, h + hh + 0.9, cz, 0, (y) => 0.75 + 0.4 * clamp((y + 0.9) / 1.8, 0, 1));
        // дверь и окна
        bx(cx + (doorSide * w) / 2, h, cz, 0.12, 2.0, 1.1, '#3a2a1c');
        bx(cx, h + 1.3, cz + d / 2, 1.0, 0.8, 0.12, '#243238');
        bx(cx, h + 1.3, cz - d / 2, 1.0, 0.8, 0.12, '#243238');
        this.obstacles.push(this.box(cx - w / 2, cx + w / 2, cz - d / 2, cz + d / 2, h + hh));
      };
      hut(-8, -5, 6.5, 5, 3.0, wood[0], '#a2442e', 1);
      hut(9, -6, 5, 5.5, 2.9, wood[2], '#4d6b5a', -1);
      hut(-9, 8, 5.5, 4.5, 2.8, wood[1], '#8c5a3a', 1);

      // вышка
      const tx = ox + 4;
      const tz = oz + 9;
      for (const [sx, sz] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) {
        bx(tx + sx, h, tz + sz, 0.35, 7, 0.35, '#6e5238');
        this.obstacles.push(this.circle(tx + sx, tz + sz, 0.3, h + 7));
      }
      bx(tx, h + 7, tz, 5.6, 0.3, 5.6, '#8a6a45');
      bx(tx, h + 7.3, tz + 2.7, 5.6, 0.9, 0.12, '#9a7650');
      bx(tx, h + 7.3, tz - 2.7, 5.6, 0.9, 0.12, '#9a7650');
      bx(tx + 2.7, h + 7.3, tz, 0.12, 0.9, 5.4, '#9a7650');
      bx(tx - 2.7, h + 7.3, tz, 0.12, 0.9, 5.4, '#9a7650');
      const tr = new THREE.ConeGeometry(1, 1.6, 4, 1);
      tr.rotateY(Math.PI / 4);
      tr.scale(2.3, 1, 2.3);
      tr.computeVertexNormals();
      for (const [sx, sz] of [[-2.5, -2.5], [2.5, -2.5], [-2.5, 2.5], [2.5, 2.5]]) bx(tx + sx, h + 7.3, tz + sz, 0.2, 2.2, 0.2, '#6e5238');
      add(tr, '#a2442e', tx, h + 10.4, tz);

      // ящики
      for (let i = 0; i < 9; i++) {
        const a = rng() * Math.PI * 2;
        const r = 5 + rng() * 9;
        const x = ox + Math.cos(a) * r;
        const z = oz + Math.sin(a) * r;
        if (!this.free(x, z, 1.5)) continue;
        const s = 0.9 + rng() * 0.6;
        bx(x, h, z, s, s, s, ['#8b6a3e', '#7a6038', '#9a7a48'][i % 3]);
        this.obstacles.push(this.box(x - s / 2, x + s / 2, z - s / 2, z + s / 2, h + s));
        if (rng() < 0.4 && this.free(x, z, 0.1)) {
          bx(x, h + s, z, s * 0.7, s * 0.7, s * 0.7, '#8b6a3e');
        }
      }
      // бочки
      for (let i = 0; i < 6; i++) {
        const a = rng() * Math.PI * 2;
        const r = 4 + rng() * 10;
        const x = ox + Math.cos(a) * r;
        const z = oz + Math.sin(a) * r;
        if (!this.free(x, z, 1.5)) continue;
        add(new THREE.CylinderGeometry(0.45, 0.45, 1.1, 10), ['#b8322a', '#2f5d9a', '#5a6b3a'][i % 3], x, h + 0.55, z);
        this.obstacles.push(this.circle(x, z, 0.5, h + 1.1));
      }
      // мешки с песком
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2 + rng();
        const r = 12 + rng() * 3;
        const x = ox + Math.cos(a) * r;
        const z = oz + Math.sin(a) * r;
        if (!this.free(x, z, 2)) continue;
        const ry = a + Math.PI / 2;
        const w = 3.6;
        const g = new THREE.BoxGeometry(w, 0.9, 0.8);
        add(g, '#b9a77a', x, h + 0.45, z, -ry, (y) => 0.8 + 0.3 * clamp((y + 0.45) / 0.9, 0, 1));
        const c = Math.abs(Math.cos(ry));
        const s = Math.abs(Math.sin(ry));
        const hx = (w * c + 0.8 * s) / 2;
        const hz = (w * s + 0.8 * c) / 2;
        this.obstacles.push(this.box(x - hx, x + hx, z - hz, z + hz, h + 0.9));
      }
      // флагшток
      add(new THREE.CylinderGeometry(0.07, 0.09, 8, 6), '#cfcfcf', ox, h + 4, oz - 1);
      bx(ox + 0.9, h + 7, oz - 1, 1.8, 1.1, 0.05, '#c0281f');
      this.obstacles.push(this.circle(ox, oz - 1, 0.15, h + 8));
    }
    if (!parts.length) return;
    const merged = mergeGeometries(parts)!;
    const mat = new THREE.MeshLambertMaterial({ vertexColors: true });
    const mesh = new THREE.Mesh(merged, mat);
    this.scene.add(mesh);
    this.disposables.push(merged, mat);
  }

  free(x: number, z: number, r: number) {
    for (const o of this.obstacles) {
      if (o.kind === 0) {
        if (Math.hypot(o.x - x, o.z - z) < o.r + r) return false;
      } else if (x > o.minX - r && x < o.maxX + r && z > o.minZ - r && z < o.maxZ + r) return false;
    }
    return true;
  }

  // ---------- коллизии ----------
  private buildCells() {
    for (const o of this.obstacles) {
      const x0 = Math.floor((o.minX - 1.5 + HALF) / CELL);
      const x1 = Math.floor((o.maxX + 1.5 + HALF) / CELL);
      const z0 = Math.floor((o.minZ - 1.5 + HALF) / CELL);
      const z1 = Math.floor((o.maxZ + 1.5 + HALF) / CELL);
      for (let cz = Math.max(z0, 0); cz <= Math.min(z1, GN - 1); cz++)
        for (let cx = Math.max(x0, 0); cx <= Math.min(x1, GN - 1); cx++) this.cells[cz * GN + cx].push(o);
    }
  }

  private cellAt(x: number, z: number) {
    const cx = Math.floor((x + HALF) / CELL);
    const cz = Math.floor((z + HALF) / CELL);
    if (cx < 0 || cz < 0 || cx >= GN || cz >= GN) return null;
    return this.cells[cz * GN + cx];
  }

  /** выталкивает круг из препятствий; feetY — высота ног (чтобы можно было запрыгнуть на ящик) */
  collide(p: { x: number; z: number }, r: number, feetY: number) {
    const list = this.cellAt(p.x, p.z);
    if (!list) return;
    for (const o of list) {
      if (feetY >= o.top - 0.25) continue;
      if (o.kind === 0) {
        const dx = p.x - o.x;
        const dz = p.z - o.z;
        const rr = o.r + r;
        const d2 = dx * dx + dz * dz;
        if (d2 < rr * rr) {
          const d = Math.sqrt(d2) || 0.0001;
          p.x = o.x + (dx / d) * rr;
          p.z = o.z + (dz / d) * rr;
        }
      } else {
        const cx = clamp(p.x, o.minX, o.maxX);
        const cz = clamp(p.z, o.minZ, o.maxZ);
        const dx = p.x - cx;
        const dz = p.z - cz;
        const d2 = dx * dx + dz * dz;
        if (d2 < r * r) {
          if (d2 > 1e-8) {
            const d = Math.sqrt(d2);
            p.x = cx + (dx / d) * r;
            p.z = cz + (dz / d) * r;
          } else {
            const l = p.x - o.minX;
            const rt = o.maxX - p.x;
            const t = p.z - o.minZ;
            const b = o.maxZ - p.z;
            const m = Math.min(l, rt, t, b);
            if (m === l) p.x = o.minX - r;
            else if (m === rt) p.x = o.maxX + r;
            else if (m === t) p.z = o.minZ - r;
            else p.z = o.maxZ + r;
          }
        }
      }
    }
  }

  groundAt(x: number, z: number, feetY: number) {
    let g = this.heightAt(x, z);
    const list = this.cellAt(x, z);
    if (list) {
      for (const o of list) {
        if (o.kind === 1 && x > o.minX && x < o.maxX && z > o.minZ && z < o.maxZ && feetY >= o.top - 0.3 && o.top > g) g = o.top;
      }
    }
    return g;
  }

  /** Возвращает t, где луч упирается в мир, либо Infinity */
  rayBlocked(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, maxT: number) {
    const step = 0.5;
    for (let t = 0.6; t < maxT; t += step) {
      const x = ox + dx * t;
      const y = oy + dy * t;
      const z = oz + dz * t;
      if (y < this.heightAt(x, z)) return t;
      const list = this.cellAt(x, z);
      if (list) {
        for (const o of list) {
          if (y > o.top) continue;
          if (o.kind === 0) {
            const ddx = x - o.x;
            const ddz = z - o.z;
            if (ddx * ddx + ddz * ddz < o.r * o.r) return t;
          } else if (x > o.minX && x < o.maxX && z > o.minZ && z < o.maxZ) return t;
        }
      }
    }
    return Infinity;
  }

  update(time: number, cam: THREE.Vector3) {
    this.uTime.value = time;
    this.sky.position.copy(cam);
    for (const c of this.clouds) {
      c.a += c.sp * 0.016;
      c.s.position.set(cam.x + Math.cos(c.a) * c.r, c.y, cam.z + Math.sin(c.a) * c.r);
    }
  }

  dispose() {
    this.disposables.forEach((d) => d.dispose());
    this.scene.traverse((o) => {
      if ((o as THREE.InstancedMesh).isInstancedMesh) (o as THREE.InstancedMesh).dispose();
    });
  }
}
