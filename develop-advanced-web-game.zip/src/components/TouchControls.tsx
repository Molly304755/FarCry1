import { memo, useRef, useState } from 'react';
import type { PointerEvent as RPE } from 'react';
import type { Game } from '../game/engine';

const SENS = 0.0052;
const R = 58;
const SR = 'max(1.5rem, env(safe-area-inset-right))';
const SB = 'max(1.75rem, env(safe-area-inset-bottom))';
const SL = 'max(1rem, env(safe-area-inset-left))';

function FireButton({ game, pos, size }: { game: Game; pos: React.CSSProperties; size: number }) {
  const [on, setOn] = useState(false);
  const last = useRef<{ id: number; x: number; y: number } | null>(null);
  return (
    <div
      className={`no-select absolute z-20 rounded-full flex items-center justify-center border-2 transition-colors ${on ? 'bg-red-500/70 border-red-200' : 'bg-red-600/35 border-white/50'} backdrop-blur-[2px]`}
      style={{ width: size, height: size, ...pos }}
      onPointerDown={(e: RPE) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        last.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
        game.input.fire = true;
        setOn(true);
      }}
      onPointerMove={(e: RPE) => {
        const l = last.current;
        if (!l || l.id !== e.pointerId) return;
        game.input.lookX += (e.clientX - l.x) * SENS * 0.9;
        game.input.lookY += (e.clientY - l.y) * SENS * 0.9;
        l.x = e.clientX;
        l.y = e.clientY;
      }}
      onPointerUp={() => {
        last.current = null;
        game.input.fire = false;
        setOn(false);
      }}
      onPointerCancel={() => {
        last.current = null;
        game.input.fire = false;
        setOn(false);
      }}
    >
      <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.8" strokeLinecap="round">
        <circle cx="12" cy="12" r="7" />
        <circle cx="12" cy="12" r="1.6" fill="white" />
        <path d="M12 2v4M12 18v4M2 12h4M18 12h4" />
      </svg>
    </div>
  );
}

function RoundBtn({ pos, size = 52, onDown, onUp, active, children }: { pos: React.CSSProperties; size?: number; onDown: () => void; onUp?: () => void; active?: boolean; children: React.ReactNode }) {
  return (
    <div
      className={`no-select absolute z-20 rounded-full flex items-center justify-center border-2 text-white font-semibold backdrop-blur-[2px] ${active ? 'bg-amber-400/60 border-amber-100' : 'bg-black/35 border-white/45'}`}
      style={{ width: size, height: size, ...pos }}
      onPointerDown={(e: RPE) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        onDown();
      }}
      onPointerUp={() => onUp?.()}
      onPointerCancel={() => onUp?.()}
    >
      {children}
    </div>
  );
}

function TouchControlsImpl({ game }: { game: Game }) {
  const baseRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const joy = useRef<{ id: number | null; ox: number; oy: number }>({ id: null, ox: 0, oy: 0 });
  const look = useRef<{ id: number | null; x: number; y: number }>({ id: null, x: 0, y: 0 });
  const [aim, setAim] = useState(false);
  const [jumpOn, setJumpOn] = useState(false);

  const joyEnd = () => {
    joy.current.id = null;
    game.input.mx = 0;
    game.input.mz = 0;
    game.input.sprint = false;
    if (baseRef.current) baseRef.current.style.display = 'none';
  };

  return (
    <div className="absolute inset-0 z-10 no-select" style={{ touchAction: 'none' }}>
      {/* зона джойстика */}
      <div
        className="absolute left-0 top-0 h-full w-[46%]"
        onPointerDown={(e) => {
          if (joy.current.id !== null) return;
          e.currentTarget.setPointerCapture(e.pointerId);
          joy.current = { id: e.pointerId, ox: e.clientX, oy: e.clientY };
          const b = baseRef.current;
          if (b) {
            b.style.display = 'block';
            b.style.left = `${e.clientX - R - 12}px`;
            b.style.top = `${e.clientY - R - 12}px`;
          }
          if (knobRef.current) knobRef.current.style.transform = 'translate(0px,0px)';
        }}
        onPointerMove={(e) => {
          const j = joy.current;
          if (j.id !== e.pointerId) return;
          let dx = e.clientX - j.ox;
          let dy = e.clientY - j.oy;
          const d = Math.hypot(dx, dy);
          if (d > R) {
            dx = (dx / d) * R;
            dy = (dy / d) * R;
          }
          if (knobRef.current) knobRef.current.style.transform = `translate(${dx}px,${dy}px)`;
          let mx = dx / R;
          let mz = -dy / R;
          const m = Math.hypot(mx, mz);
          if (m < 0.12) {
            mx = 0;
            mz = 0;
          }
          game.input.mx = mx;
          game.input.mz = mz;
          game.input.sprint = m > 0.96 && mz > 0.6;
        }}
        onPointerUp={joyEnd}
        onPointerCancel={joyEnd}
      />
      <div ref={baseRef} className="pointer-events-none fixed hidden rounded-full border-2 border-white/40 bg-white/10" style={{ width: R * 2 + 24, height: R * 2 + 24 }}>
        <div ref={knobRef} className="absolute rounded-full bg-white/55 border border-white/80" style={{ width: 56, height: 56, left: R + 12 - 28, top: R + 12 - 28 }} />
      </div>

      {/* зона обзора */}
      <div
        className="absolute right-0 top-0 h-full w-[54%]"
        onPointerDown={(e) => {
          if (look.current.id !== null) return;
          e.currentTarget.setPointerCapture(e.pointerId);
          look.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
        }}
        onPointerMove={(e) => {
          const l = look.current;
          if (l.id !== e.pointerId) return;
          game.input.lookX += (e.clientX - l.x) * SENS;
          game.input.lookY += (e.clientY - l.y) * SENS;
          l.x = e.clientX;
          l.y = e.clientY;
        }}
        onPointerUp={() => (look.current.id = null)}
        onPointerCancel={() => (look.current.id = null)}
      />

      {/* кнопки */}
      <FireButton game={game} size={92} pos={{ right: SR, bottom: SB }} />
      <FireButton game={game} size={64} pos={{ left: SL, top: '46%' }} />
      <RoundBtn
        pos={{ right: `calc(${SR} + 104px)`, bottom: `calc(${SB} - 8px)` }}
        size={58}
        active={aim}
        onDown={() => {
          const v = !game.input.aim;
          game.input.aim = v;
          setAim(v);
        }}
      >
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.8" strokeLinecap="round">
          <circle cx="12" cy="12" r="8" />
          <path d="M12 1v6M12 17v6M1 12h6M17 12h6" />
        </svg>
      </RoundBtn>
      <RoundBtn
        pos={{ right: `calc(${SR} + 92px)`, bottom: `calc(${SB} + 84px)` }}
        size={54}
        active={jumpOn}
        onDown={() => {
          game.input.jump = true;
          setJumpOn(true);
        }}
        onUp={() => setJumpOn(false)}
      >
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
          <path d="M6 14l6-6 6 6M6 20l6-6 6 6" />
        </svg>
      </RoundBtn>
      <RoundBtn
        pos={{ right: SR, bottom: `calc(${SB} + 112px)` }}
        size={50}
        onDown={() => {
          game.input.reload = true;
        }}
      >
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20 12a8 8 0 1 1-2.5-5.8M20 4v5h-5" />
        </svg>
      </RoundBtn>
    </div>
  );
}

export const TouchControls = memo(TouchControlsImpl);
