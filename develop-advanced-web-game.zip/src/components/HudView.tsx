import { useEffect, useRef } from 'react';
import type { Game, Hud } from '../game/engine';

export interface HurtFx {
  k: number;
  a: number;
}
export interface HitFx {
  k: number;
  head: boolean;
  kill: boolean;
}

export function HudView({ game, hud, hurt, hit, toast, touch, onPause }: { game: Game; hud: Hud | null; hurt: HurtFx | null; hit: HitFx | null; toast: { k: number; t: string } | null; touch: boolean; onPause: () => void }) {
  const mapRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    game.mapCanvas = mapRef.current;
    return () => {
      game.mapCanvas = null;
    };
  }, [game]);

  const hp = hud?.hp ?? 100;
  const low = hp < 35;
  const gap = 8 + (hud?.spread ?? 0) * 22;
  const aim = hud?.aim;

  return (
    <div className="absolute inset-0 z-[5] pointer-events-none no-select text-white">
      {/* виньетка */}
      <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,20,30,0.45) 100%)' }} />
      {low && <div className="absolute inset-0" style={{ boxShadow: 'inset 0 0 140px 30px rgba(220,0,0,0.65)', animation: 'pulse-red 1.1s infinite' }} />}

      {/* индикатор урона */}
      {hurt && (
        <div key={hurt.k} className="absolute inset-0 anim-hurt">
          <div className="absolute inset-0" style={{ boxShadow: 'inset 0 0 120px 20px rgba(255,0,0,0.5)' }} />
          <div className="absolute left-1/2 top-1/2" style={{ width: 0, height: 0, transform: `rotate(${hurt.a}rad)` }}>
            <div className="absolute -translate-x-1/2" style={{ top: -190, width: 130, height: 38, background: 'radial-gradient(ellipse at 50% 0%, rgba(255,30,30,0.95), rgba(255,30,30,0) 70%)' }} />
          </div>
        </div>
      )}

      {/* прицел */}
      {!aim ? (
        <div className="absolute left-1/2 top-1/2">
          <div className="absolute w-[3px] h-[3px] -ml-[1.5px] -mt-[1.5px] rounded-full bg-white shadow-[0_0_3px_#000]" />
          {[0, 90, 180, 270].map((r) => (
            <div key={r} className="absolute" style={{ transform: `rotate(${r}deg) translateY(${-gap}px)`, transformOrigin: '0 0' }}>
              <div className="w-[2px] h-[8px] -ml-[1px] -mt-[8px] bg-white/90 shadow-[0_0_3px_#000]" />
            </div>
          ))}
        </div>
      ) : (
        <div className="absolute left-1/2 top-1/2">
          <div className="absolute w-[5px] h-[5px] -ml-[2.5px] -mt-[2.5px] rounded-full bg-red-500 shadow-[0_0_6px_#f00]" />
          <div className="absolute w-[34px] h-[34px] -ml-[17px] -mt-[17px] rounded-full border border-white/40" />
        </div>
      )}
      {hit && (
        <div key={hit.k} className="absolute left-1/2 top-1/2 anim-hit">
          {[45, 135, 225, 315].map((r) => (
            <div key={r} className="absolute" style={{ transform: `rotate(${r}deg) translateY(-10px)`, transformOrigin: '0 0' }}>
              <div className="w-[3px] h-[10px] -ml-[1.5px] rounded" style={{ background: hit.kill ? '#ff3b30' : hit.head ? '#ffd23f' : '#fff', boxShadow: '0 0 4px #000' }} />
            </div>
          ))}
        </div>
      )}

      {/* миникарта */}
      <div className="absolute left-[max(0.75rem,env(safe-area-inset-left))] top-[max(0.75rem,env(safe-area-inset-top))] flex flex-col gap-1.5 items-start">
        <div className="relative rounded-full p-[3px] bg-black/50 border border-white/40 shadow-lg">
          <canvas ref={mapRef} width={touch ? 112 : 136} height={touch ? 112 : 136} className="rounded-full block" />
          <div className="absolute left-1/2 top-[5px] -translate-x-1/2 text-[10px] font-bold text-white/90 drop-shadow">N↑</div>
        </div>
        <div className="px-2.5 py-1 rounded-md bg-black/45 border border-white/15 text-[13px] leading-tight tracking-wide">
          <span className="text-amber-300 font-semibold">ВРАГИ</span> {hud?.enemies ?? 0}
          <span className="text-white/50"> / {hud?.total ?? 0}</span>
          {hud?.alert && <span className="ml-1.5 text-red-400 font-bold animate-pulse">! ТРЕВОГА</span>}
        </div>
      </div>

      {/* верх справа */}
      <div className="absolute right-[max(0.75rem,env(safe-area-inset-right))] top-[max(0.75rem,env(safe-area-inset-top))] flex items-start gap-2">
        <div className="text-[10px] text-white/60 text-right leading-tight pt-0.5">
          {hud?.fps ?? 0} FPS<br />разрешение {hud?.scale ?? 100}%
        </div>
        <button className="pointer-events-auto w-10 h-10 rounded-lg bg-black/45 border border-white/30 flex items-center justify-center active:bg-white/20" onClick={onPause} aria-label="Пауза">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="white">
            <rect x="3" y="2" width="3.5" height="12" rx="1" />
            <rect x="9.5" y="2" width="3.5" height="12" rx="1" />
          </svg>
        </button>
      </div>

      {/* низ по центру: здоровье и патроны */}
      <div className="absolute left-1/2 -translate-x-1/2 bottom-[max(0.75rem,env(safe-area-inset-bottom))] flex items-end gap-3">
        <div className="rounded-lg bg-black/50 border border-white/20 px-3 py-1.5 w-[150px] sm:w-[190px]">
          <div className="flex justify-between text-[11px] tracking-widest text-white/70">
            <span>ЗДОРОВЬЕ</span>
            <span className={low ? 'text-red-400 font-bold' : 'text-white'}>{hp}</span>
          </div>
          <div className="mt-1 h-2.5 rounded bg-white/15 overflow-hidden">
            <div className="h-full rounded transition-all duration-150" style={{ width: `${hp}%`, background: low ? 'linear-gradient(90deg,#ff3b30,#ff6a3d)' : 'linear-gradient(90deg,#3fe08a,#b7f04a)' }} />
          </div>
        </div>
        <div className="rounded-lg bg-black/50 border border-white/20 px-3 py-1 min-w-[110px] text-right">
          {hud?.reloading ? (
            <div className="text-amber-300 text-sm font-semibold tracking-widest py-1.5 animate-pulse">ПЕРЕЗАРЯДКА</div>
          ) : (
            <div className="leading-none">
              <span className={`text-3xl font-bold ${(hud?.ammo ?? 30) <= 8 ? 'text-red-400' : 'text-white'}`}>{hud?.ammo ?? 30}</span>
              <span className="text-white/60 text-lg"> / {hud?.reserve ?? 0}</span>
            </div>
          )}
        </div>
      </div>

      {toast && (
        <div key={toast.k} className="absolute left-1/2 top-[22%] -translate-x-1/2 anim-toast px-4 py-1.5 rounded-full bg-black/55 border border-white/25 text-sm tracking-wider">
          {toast.t}
        </div>
      )}
    </div>
  );
}
